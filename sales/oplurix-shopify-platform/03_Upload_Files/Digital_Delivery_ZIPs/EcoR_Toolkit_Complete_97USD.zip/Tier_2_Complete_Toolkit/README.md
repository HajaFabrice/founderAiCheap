# EcoR Toolkit - Complete

Price: USD $97

## What You Get

- Everything in Starter
- 5 ready-to-use field data templates in CSV format
- 5 advanced context CSV templates from the v3 workflow: transects, camera traps, focal follows, CTmax, and genetics sample metadata
- 3 publication figure templates for ggplot2
- "From Field Notes to Results Section" workflow guide
- Grant proposal data analysis section template
- EcoR Project Template bonus: a practical RStudio workspace for organizing data, scripts, figures, tables, reports, and helper functions
- Complete-tier workflow decision tree for choosing the right scripts

## Best For

Researchers who want the full workflow: clean data templates, R scripts, reusable figures, writing support, and a structured project folder they can reuse for real biodiversity analyses.

## Start Here

1. Copy a CSV template from `04_Data_Templates/`
2. Use `04_Data_Templates/Advanced_Context_Templates/` if your project matches a specific field-data context
3. Fill the copied template with your field observations
4. Run the R scripts in numeric order
5. Use the workflow guide in `05_Workflow_Guides/`
6. Open `07_Project_Template/EcoR_Project_Template/` when you want a full RStudio project workspace
