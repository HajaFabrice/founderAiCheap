# Advanced Context Templates

These templates come from the upgraded EcoR full-project workflow. Use them when your data match a specific field context:

- `TEMPLATE_transect_survey.csv` for species/transect observations
- `TEMPLATE_camera_trap_records.csv` for camera-trap detections
- `TEMPLATE_focal_follows.csv` for behavioural focal follows
- `TEMPLATE_ecophysiology_CTmax.csv` for thermal tolerance data
- `TEMPLATE_genetics_tissue_samples.csv` for genetics sample metadata

Keep raw data unchanged in your project. Copy the relevant template, rename it, and fill the copy with your own observations.
