# ============================================================================== 
# EcoR Project Template: 0_setup.R
# Purpose: Initialize folders, packages, and example data.
# ==============================================================================

required_packages <- c(
  "here", "tidyverse", "janitor", "lubridate", "vegan",
  "ggplot2", "patchwork", "viridis", "broom", "gt", "quarto"
)

if (!requireNamespace("here", quietly = TRUE)) {
  install.packages("here")
}

here::i_am("0_setup.R")

dirs <- c(
  "data/raw", "data/processed", "data/example",
  "outputs/figures", "outputs/tables",
  "reports", "docs", "functions"
)

for (dir in dirs) {
  dir.create(here::here(dir), recursive = TRUE, showWarnings = FALSE)
}

missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]

if (length(missing_packages) > 0) {
  install.packages(missing_packages)
}
source(here::here("functions", "utils_data.R"))

set.seed(2026)

example_occurrences <- tibble::tibble(
  record_id = sprintf("OBS%03d", 1:80),
  species = sample(
    c("Eulemur fulvus", "Propithecus diadema", "Microcebus rufus", "Varecia variegata"),
    80,
    replace = TRUE,
    prob = c(0.35, 0.20, 0.30, 0.15)
  ),
  longitude = stats::runif(80, 48.20, 48.72),
  latitude = stats::runif(80, -19.10, -18.72),
  date = as.Date("2026-01-01") + sample(0:90, 80, replace = TRUE),
  count = sample(1:8, 80, replace = TRUE),
  site = sample(paste0("Forest_", LETTERS[1:6]), 80, replace = TRUE),
  elevation = round(stats::runif(80, 300, 1450)),
  forest_cover = round(stats::runif(80, 0.15, 0.98), 2),
  distance_to_road = round(stats::runif(80, 100, 9000)),
  presence = 1
)

example_absences <- tibble::tibble(
  record_id = sprintf("BG%03d", 1:80),
  species = sample(unique(example_occurrences$species), 80, replace = TRUE),
  longitude = stats::runif(80, 48.20, 48.72),
  latitude = stats::runif(80, -19.10, -18.72),
  date = as.Date("2026-01-01") + sample(0:90, 80, replace = TRUE),
  count = 0,
  site = sample(paste0("Forest_", LETTERS[1:6]), 80, replace = TRUE),
  elevation = round(stats::runif(80, 300, 1450)),
  forest_cover = round(stats::runif(80, 0.05, 0.85), 2),
  distance_to_road = round(stats::runif(80, 100, 9000)),
  presence = 0
)

example_sdm <- dplyr::bind_rows(example_occurrences, example_absences)

if (!file.exists(here::here("data", "example", "occurrences.csv"))) {
  readr::write_csv(example_occurrences, here::here("data", "example", "occurrences.csv"))
}

if (!file.exists(here::here("data", "example", "sdm_training.csv"))) {
  readr::write_csv(example_sdm, here::here("data", "example", "sdm_training.csv"))
}

writeLines(capture.output(sessionInfo()), here::here("outputs", "session_info.txt"))

message("EcoR Project Template (Complete tier) setup complete.")
message("Project root: ", here::here())



