# ==============================================================================
# EcoR Project Template (Complete tier): 2_exploratory_analysis.R
# Purpose: Exploratory analysis and quality checks for conservation datasets.
# ==============================================================================

library(here)
library(readr)
library(dplyr)
library(ggplot2)

here::i_am("2_exploratory_analysis.R")
source(here("functions", "utils_figures.R"))

INPUT_FILE <- here("data", "processed", "occurrences_clean.csv")
if (!file.exists(INPUT_FILE)) {
  source(here("1_data_import_clean.R"))
}

occ <- readr::read_csv(INPUT_FILE, show_col_types = FALSE)

species_summary <- occ |>
  count(species, sort = TRUE, name = "records") |>
  mutate(percent = round(100 * records / sum(records), 1))

site_summary <- occ |>
  group_by(site) |>
  summarise(
    records = n(),
    total_count = sum(count, na.rm = TRUE),
    species_richness = n_distinct(species),
    .groups = "drop"
  ) |>
  arrange(desc(species_richness), desc(total_count))

readr::write_csv(species_summary, here("outputs", "tables", "species_summary.csv"))
readr::write_csv(site_summary, here("outputs", "tables", "site_summary.csv"))

species_plot <- ggplot(species_summary, aes(x = reorder(species, records), y = records)) +
  geom_col(fill = "#2f6f5e") +
  coord_flip() +
  labs(title = "Species Records", x = NULL, y = "Number of records") +
  theme_ecor_complete()

save_ecor_plot(
  species_plot,
  here("outputs", "figures", "species_records.png"),
  width = 7,
  height = 4.5
)

message("Exploratory summaries and figures exported.")


