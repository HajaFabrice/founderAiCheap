# ==============================================================================
# EcoR Project Template (Complete tier): 4_biodiversity_metrics.R
# Purpose: Calculate site-level diversity and community metrics.
# ==============================================================================

library(here)
library(readr)
library(dplyr)
library(tidyr)
library(ggplot2)

here::i_am("4_biodiversity_metrics.R")
source(here("functions", "utils_data.R"))
source(here("functions", "utils_diversity.R"))
source(here("functions", "utils_figures.R"))

INPUT_FILE <- here("data", "processed", "occurrences_clean.csv")
if (!file.exists(INPUT_FILE)) {
  source(here("1_data_import_clean.R"))
}

occ <- readr::read_csv(INPUT_FILE, show_col_types = FALSE)

community <- occ |>
  group_by(site, species) |>
  summarise(abundance = sum(count, na.rm = TRUE), .groups = "drop") |>
  tidyr::pivot_wider(names_from = species, values_from = abundance, values_fill = 0)

community_matrix <- community |>
  tibble::column_to_rownames("site")

diversity_metrics <- calculate_diversity_metrics(community_matrix)

readr::write_csv(diversity_metrics, here("outputs", "tables", "diversity_metrics.csv"))

diversity_plot <- ggplot(diversity_metrics, aes(x = reorder(site, shannon), y = shannon)) +
  geom_col(fill = "#4477aa") +
  coord_flip() +
  labs(title = "Site-Level Shannon Diversity", x = NULL, y = "Shannon diversity") +
  theme_ecor_complete()

save_ecor_plot(diversity_plot, here("outputs", "figures", "site_diversity.png"))

message("Biodiversity metrics complete.")


