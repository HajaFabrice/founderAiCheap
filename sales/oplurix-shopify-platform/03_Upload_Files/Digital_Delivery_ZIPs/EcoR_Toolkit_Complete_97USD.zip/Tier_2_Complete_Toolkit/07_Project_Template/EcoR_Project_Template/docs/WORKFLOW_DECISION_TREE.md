# EcoR Complete Workflow Decision Tree

Use this guide to decide which EcoR Project Template scripts to run in the Complete tier.

## I Have Raw Species or Transect Data

Start here:

```r
source("1_data_import_clean.R")
source("2_exploratory_analysis.R")
```

Outputs:

- Cleaned CSV file in `data/processed/`
- Species/site summaries in `outputs/tables/`
- Basic exploratory figures in `outputs/figures/`

## I Need Biodiversity Metrics

```r
source("4_biodiversity_metrics.R")
```

Outputs:

- Species richness
- Abundance summaries
- Shannon diversity
- Simpson diversity
- Site diversity figure

## I Need Report-Ready Figures

```r
source("7_visualization_publication.R")
```

Outputs:

- Clean ggplot2 figures for reports, proposals, and manuscripts
- Exported image files in `outputs/figures/`

## I Need a Final Report

After generating tables and figures, render:

```r
quarto::quarto_render("8_reporting.qmd", output_dir = "reports")
```

## I Need Maps, SDM, Population Dynamics, or Full Automation

Those advanced workflows are included in EcoR Toolkit Pro through the full reproducible conservation project template.
