# Data Dictionary

EcoR Project Template works best when occurrence data follow this structure.

| Column | Type | Required | Description |
|---|---|---:|---|
| `record_id` | character | No | Unique observation identifier |
| `species` | character | Yes | Scientific or common species name |
| `longitude` | numeric | Yes | Longitude in decimal degrees |
| `latitude` | numeric | Yes | Latitude in decimal degrees |
| `date` | date | Yes | Observation date |
| `count` | numeric | Yes | Count, detection, or abundance value |
| `site` | character | Yes | Site, transect, camera, or survey station |
| `elevation` | numeric | No | Elevation in meters |
| `forest_cover` | numeric | No | Proportion or index from 0 to 1 |
| `distance_to_road` | numeric | No | Distance to nearest road in meters |
| `presence` | numeric | No | 1 for presence, 0 for absence/background |

For mapping or Pro spatial workflows, keep coordinates in WGS84 longitude and latitude unless you intentionally change the coordinate reference system.



