#' EcoR Project Template (Complete tier) ggplot theme.
#'
#' @return A ggplot2 theme object.
theme_ecor_complete <- function() {
  ggplot2::theme_minimal(base_size = 12) +
    ggplot2::theme(
      panel.grid.minor = ggplot2::element_blank(),
      plot.title = ggplot2::element_text(face = "bold"),
      plot.subtitle = ggplot2::element_text(color = "gray30"),
      legend.position = "right"
    )
}

#' Save a figure with consistent defaults.
#'
#' @param plot ggplot object.
#' @param filename Output filename.
#' @param width Width in inches.
#' @param height Height in inches.
#' @return The filename invisibly.
save_ecor_plot <- function(plot, filename, width = 8, height = 5) {
  dir.create(dirname(filename), recursive = TRUE, showWarnings = FALSE)
  ggplot2::ggsave(filename, plot, width = width, height = height, dpi = 300)
  invisible(filename)
}


