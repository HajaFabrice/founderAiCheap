#' Calculate site-level diversity metrics.
#'
#' @param community_matrix Matrix or data frame of sites by species.
#' @return Tibble with richness, abundance, Shannon, and Simpson metrics.
calculate_diversity_metrics <- function(community_matrix) {
  load_required_packages(c("dplyr", "tibble", "vegan"))

  mat <- as.matrix(community_matrix)
  tibble::tibble(
    site = rownames(mat) %||% paste0("site_", seq_len(nrow(mat))),
    richness = vegan::specnumber(mat),
    abundance = rowSums(mat, na.rm = TRUE),
    shannon = vegan::diversity(mat, index = "shannon"),
    simpson = vegan::diversity(mat, index = "simpson"),
    inv_simpson = vegan::diversity(mat, index = "invsimpson")
  )
}

`%||%` <- function(x, y) {
  if (is.null(x)) y else x
}


