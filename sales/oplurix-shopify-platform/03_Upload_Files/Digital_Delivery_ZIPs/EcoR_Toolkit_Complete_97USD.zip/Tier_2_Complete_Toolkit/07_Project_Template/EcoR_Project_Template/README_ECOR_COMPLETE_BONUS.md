# EcoR Project Template Bonus

This folder is included with EcoR Toolkit Complete as a practical project workspace for real ecology and conservation analysis.

Use it when you want a clean RStudio project structure around your EcoR scripts: raw data, processed data, reusable helper functions, outputs, reports, and documentation all have a predictable home.

## Included in Complete

- RStudio project file: `EcoR_Project_Template.Rproj`
- Core scripts for setup, data cleaning, exploratory analysis, biodiversity metrics, figure export, and reporting
- Helper functions for data checks, diversity summaries, and publication-style figures
- Data dictionary and workflow decision tree
- Empty folders for raw data, processed data, reports, figures, and tables

## Not Included Here

Advanced automation files such as `_targets.R`, `run_pipeline.R`, `renv`, spatial analysis, species distribution modeling, and population dynamics are reserved for EcoR Toolkit Pro.

## Recommended Use

1. Open `EcoR_Project_Template.Rproj` in RStudio.
2. Put original field files in `data/raw/`.
3. Start with `0_setup.R`.
4. Run the relevant numbered scripts for your project.
5. Save final figures in `outputs/figures/` and report tables in `outputs/tables/`.
