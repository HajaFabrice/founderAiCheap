# ==============================================================================
# EcoR Project Template (Complete tier): 1_data_import_clean.R
# Purpose: Import, clean, validate, and save conservation occurrence data.
# ==============================================================================

library(here)
library(readr)
library(dplyr)

here::i_am("1_data_import_clean.R")
source(here("functions", "utils_data.R"))

INPUT_FILE <- here("data", "raw", "occurrences.csv")
EXAMPLE_FILE <- here("data", "example", "occurrences.csv")
OUTPUT_FILE <- here("data", "processed", "occurrences_clean.csv")
QA_FILE <- here("outputs", "tables", "data_quality_summary.csv")

input_path <- if (file.exists(INPUT_FILE)) INPUT_FILE else EXAMPLE_FILE

raw_occurrences <- readr::read_csv(input_path, show_col_types = FALSE)
clean_occurrences <- clean_occurrence_data(raw_occurrences)

quality_summary <- tibble::tibble(
  metric = c("input_file", "raw_rows", "clean_rows", "species_count", "site_count"),
  value = c(
    basename(input_path),
    nrow(raw_occurrences),
    nrow(clean_occurrences),
    dplyr::n_distinct(clean_occurrences$species),
    dplyr::n_distinct(clean_occurrences$site)
  )
)

write_csv_safe(clean_occurrences, OUTPUT_FILE)
write_csv_safe(quality_summary, QA_FILE)

message("Cleaned occurrence data written to: ", OUTPUT_FILE)


