# EcoR Project Template User Guide

Version 1.0 - Complete tier bonus

## 1. Five-Minute Quick Start

1. Open `EcoR_Project_Template.Rproj` in RStudio.
2. Put original field files in `data/raw/`.
3. Run `source("0_setup.R")`.
4. Run `source("1_data_import_clean.R")` and adapt the parameter section to your CSV columns.
5. Continue with exploratory analysis, biodiversity metrics, figures, or the report template as needed.

## 2. What Each File Does

| File | Use |
|---|---|
| `0_setup.R` | Installs packages, creates folders, and prepares the project |
| `1_data_import_clean.R` | Cleans occurrence and survey-style datasets |
| `2_exploratory_analysis.R` | Produces quality checks and exploratory summaries |
| `4_biodiversity_metrics.R` | Calculates diversity and community metrics |
| `7_visualization_publication.R` | Creates clean figures for reports and papers |
| `8_reporting.qmd` | Builds a starter report |

## 3. Using Your Own Data

Keep original files in `data/raw/`. Do not edit raw files directly. Instead, change the parameters at the top of each script and save cleaned files to `data/processed/`.

Recommended minimum columns for occurrence or transect-style data:

| Column | Example |
|---|---|
| `record_id` | `OBS001` |
| `species` | `Eulemur fulvus` |
| `longitude` | `48.45` |
| `latitude` | `-18.94` |
| `date` | `2026-05-11` |
| `count` | `3` |
| `site` | `Forest_A` |

## 4. Suggested Workflows

Basic cleaning and quality check:

```r
source("1_data_import_clean.R")
source("2_exploratory_analysis.R")
```

Biodiversity survey summary:

```r
source("1_data_import_clean.R")
source("4_biodiversity_metrics.R")
source("7_visualization_publication.R")
```

Report drafting:

```r
quarto::quarto_render("8_reporting.qmd")
```

## 5. Troubleshooting

If a package is missing, run:

```r
source("0_setup.R")
```

If a script cannot find your file, confirm the file is inside `data/raw/` and that the filename in the script matches exactly.

## 6. Customization

- Edit script parameters first.
- Add project-specific helper functions in `functions/`.
- Keep notes and data definitions in `docs/`.
- Keep generated outputs in `outputs/` and `reports/`.
