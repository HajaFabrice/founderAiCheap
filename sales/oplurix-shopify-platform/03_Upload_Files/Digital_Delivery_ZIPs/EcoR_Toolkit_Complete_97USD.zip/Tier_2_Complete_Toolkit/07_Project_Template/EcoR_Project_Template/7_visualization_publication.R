# ==============================================================================
# EcoR Project Template (Complete tier): 7_visualization_publication.R
# Purpose: Publication-ready figures assembled from project outputs.
# ==============================================================================

library(here)
library(readr)
library(dplyr)
library(ggplot2)
library(patchwork)

here::i_am("7_visualization_publication.R")
source(here("functions", "utils_figures.R"))

needed_tables <- c(
  here("outputs", "tables", "species_summary.csv"),
  here("outputs", "tables", "diversity_metrics.csv")
)

if (!all(file.exists(needed_tables))) {
  source(here("2_exploratory_analysis.R"))
  source(here("4_biodiversity_metrics.R"))
}

species_summary <- readr::read_csv(here("outputs", "tables", "species_summary.csv"), show_col_types = FALSE)
diversity_metrics <- readr::read_csv(here("outputs", "tables", "diversity_metrics.csv"), show_col_types = FALSE)

p1 <- ggplot(species_summary, aes(x = reorder(species, records), y = records)) +
  geom_col(fill = "#2f6f5e") +
  coord_flip() +
  labs(title = "A. Species records", x = NULL, y = "Records") +
  theme_ecor_complete()

p2 <- ggplot(diversity_metrics, aes(x = reorder(site, richness), y = richness)) +
  geom_col(fill = "#cc6677") +
  coord_flip() +
  labs(title = "B. Site richness", x = NULL, y = "Richness") +
  theme_ecor_complete()

combined <- p1 + p2 + plot_layout(widths = c(1, 1))

save_ecor_plot(combined, here("outputs", "figures", "publication_summary_panel.png"), width = 11, height = 5.5)

message("Publication figure panel exported.")


