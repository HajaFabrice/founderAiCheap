# EcoR Project Template

EcoR Project Template is a practical RStudio workspace included with EcoR Toolkit Complete. It helps you organize a real biodiversity or conservation analysis without starting from an empty folder.

It gives you a clean structure for raw data, processed data, helper functions, figures, tables, reports, and documentation. This Complete version focuses on the everyday workflow: setup, data cleaning, exploratory analysis, biodiversity metrics, figure export, and report drafting.

## Who This Is For

- Students turning field data into thesis or class-project outputs
- Field biologists who need a consistent folder structure
- NGO and conservation analysts preparing repeatable summaries
- Researchers who want cleaner R project habits without full pipeline automation

## Quick Start

1. Open `EcoR_Project_Template.Rproj` in RStudio.
2. Put original CSV files in `data/raw/`.
3. Run:

```r
source("0_setup.R")
```

4. Run the scripts you need in numeric order.
5. Export figures to `outputs/figures/`, tables to `outputs/tables/`, and reports to `reports/`.

## Included Workflow Files

| File | Purpose |
|---|---|
| `0_setup.R` | Create folders, install packages, and prepare the project |
| `1_data_import_clean.R` | Import, validate, clean, and save processed data |
| `2_exploratory_analysis.R` | Summaries, missingness checks, and preliminary plots |
| `4_biodiversity_metrics.R` | Richness, Shannon, Simpson, and community summaries |
| `7_visualization_publication.R` | Publication-style plot helpers and exports |
| `8_reporting.qmd` | Report starter for conservation analysis outputs |

## Included Helper Functions

- `functions/utils_data.R`
- `functions/utils_diversity.R`
- `functions/utils_figures.R`

## Project Structure

```text
EcoR_Project_Template/
├── 0_setup.R
├── 1_data_import_clean.R
├── 2_exploratory_analysis.R
├── 4_biodiversity_metrics.R
├── 7_visualization_publication.R
├── 8_reporting.qmd
├── functions/
├── data/
├── outputs/
├── reports/
└── docs/
```

## Pro Upgrade Note

The Pro tier includes the full reproducible conservation project template with spatial analysis, species distribution modeling, population dynamics, `_targets.R`, `run_pipeline.R`, renv guidance, and citation metadata.
