#' Load EcoR Project Template helper packages safely.
#'
#' @param packages Character vector of package names.
#' @return Invisibly returns TRUE when all packages are available.
load_required_packages <- function(packages) {
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing) > 0) {
    stop(
      "Missing packages: ", paste(missing, collapse = ", "),
      ". Run source('0_setup.R') first.",
      call. = FALSE
    )
  }
  invisible(TRUE)
}

#' Clean common conservation occurrence columns.
#'
#' @param data A data frame with species, coordinates, date, site, and count fields.
#' @return A cleaned tibble.
clean_occurrence_data <- function(data) {
  load_required_packages(c("dplyr", "janitor", "lubridate"))

  data |>
    janitor::clean_names() |>
    dplyr::mutate(
      species = trimws(as.character(.data$species)),
      site = trimws(as.character(.data$site)),
      date = lubridate::as_date(.data$date),
      count = suppressWarnings(as.numeric(.data$count)),
      longitude = suppressWarnings(as.numeric(.data$longitude)),
      latitude = suppressWarnings(as.numeric(.data$latitude))
    ) |>
    dplyr::filter(
      !is.na(.data$species),
      !is.na(.data$longitude),
      !is.na(.data$latitude),
      dplyr::between(.data$longitude, -180, 180),
      dplyr::between(.data$latitude, -90, 90)
    ) |>
    dplyr::distinct()
}

#' Write a CSV and create its parent directory if needed.
#'
#' @param data Data frame to write.
#' @param path Output path.
#' @return The output path invisibly.
write_csv_safe <- function(data, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  readr::write_csv(data, path)
  invisible(path)
}


