# EcoR Toolkit - Starter

Price: USD $29

## What You Get

- 10 annotated R scripts for common biodiversity workflows
- 50 copy-paste Claude prompts for R debugging, interpretation, figures, and scientific writing
- Quick-start guide
- One transect observation CSV template
- License and usage notes

## Best For

Students and field biologists who already have their own data structure and want scripts plus AI prompts to move faster.

## Start Here

1. Open `01_Start_Here/Quick_Start_Guide.md`
2. Copy `04_Data_Templates/transect_observations_template.csv`
3. Open `02_R_Scripts/README_R_Scripts.md`
4. Run `02_R_Scripts/11_required_packages.R`
5. Use the prompt library whenever R gives an error
