# ==============================================================================
# EcoR Toolkit — 1_data_import_clean.R
# Data loading, validation, and cleaning pipeline
# ==============================================================================
# PARAMETERS — edit these before running
# ==============================================================================

# Path to your raw data file (relative to project root)
DATA_FILE   <- "data/raw/TEMPLATE_transect_survey.csv"   # or .xlsx, .shp, etc.
DATE_COL    <- "date"                      # Name of the date column (if any)
SITE_COL    <- "site"                      # Name of the site/location column
SPECIES_COL <- "espece"                    # Name of the species column
COUNT_COL   <- "n_ind"                     # Name of the count/abundance column

# ==============================================================================
library(here); library(readr); library(readxl)
library(dplyr); library(tidyr); library(janitor); library(skimr)

cat("=== 1. DATA IMPORT & CLEANING ===\n\n")

# ── Detect file format and import ─────────────────────────────────────────────

if (!file.exists(here(DATA_FILE))) {
  cat("⚠ No data file found at:", DATA_FILE, "\n")
  cat("  → Place your CSV or Excel file in data/raw/\n")
  cat("  → Update DATA_FILE at the top of this script\n\n")
  cat("  Demo mode: generating a simulated dataset...\n\n")

  # Demo dataset (Madagascar herpetofauna)
  set.seed(42)
  data_raw <- expand.grid(
    site    = c("Foret_Primaire","Foret_Secondaire",
                "Lisiere","Savane","Zone_Agricole"),
    espece  = c("Zonosaurus_karsteni","Furcifer_lateralis",
                "Brookesia_brygooi","Oplurus_cuvieri",
                "Uroplatus_fimbriatus","Mantella_aurantiaca"),
    transect_id = paste0("T", 1:5)
  ) %>%
    mutate(
      n_ind       = rpois(n(), lambda = 3),
      date        = as.Date("2024-07-01") + sample(0:90, n(), replace = TRUE),
      habitat     = case_when(
        grepl("Primaire", site)    ~ "Primary forest",
        grepl("Secondaire", site)  ~ "Secondary forest",
        grepl("Lisiere", site)     ~ "Forest edge",
        grepl("Savane", site)      ~ "Savanna",
        TRUE                       ~ "Agricultural"
      ),
      lon = runif(n(), 44.5, 44.7),
      lat = runif(n(), -23.5, -23.3)
    )
} else {
  ext <- tools::file_ext(DATA_FILE)
  data_raw <- switch(ext,
    "csv"  = read_csv(here(DATA_FILE), show_col_types = FALSE),
    "xlsx" = read_excel(here(DATA_FILE)),
    "xls"  = read_excel(here(DATA_FILE)),
    stop("Unsupported format: ", ext,
         "\nSupported: .csv, .xlsx, .xls")
  )
}

cat("✓ Data loaded:", nrow(data_raw), "rows ×", ncol(data_raw), "columns\n\n")

# ── Clean column names ─────────────────────────────────────────────────────────

data <- data_raw %>%
  janitor::clean_names()   # lowercase, replace spaces → underscores

cat("Column names after cleaning:\n")
print(names(data))

# ── Fix types ─────────────────────────────────────────────────────────────────

cat("\nFixing column types...\n")

data <- data %>%
  mutate(
    # Date
    across(any_of(c(DATE_COL, "date")),
           ~ as.Date(as.character(.))),
    # Factors
    across(any_of(c(SITE_COL, SPECIES_COL, "site", "espece",
                    "habitat", "transect_id")),
           as.factor),
    # Counts (must be non-negative integers)
    across(any_of(c(COUNT_COL, "n_ind", "count", "abondance")),
           ~ as.integer(pmax(0, ., na.rm = TRUE)))
  )

# ── Check missing values ───────────────────────────────────────────────────────

cat("\n=== MISSING VALUES ===\n")
na_summary <- colSums(is.na(data))
print(na_summary[na_summary > 0])

if (all(na_summary == 0)) {
  cat("✓ No missing values — dataset is complete.\n")
} else {
  pct_na <- round(na_summary[na_summary > 0] / nrow(data) * 100, 1)
  cat("Columns with NA (% missing):\n")
  print(pct_na)
  cat("\n→ Choose a strategy:\n")
  cat("  • Remove rows: data <- data %>% filter(!is.na(your_col))\n")
  cat("  • Impute median: data$col[is.na(data$col)] <- median(data$col, na.rm=T)\n")
}

# ── Check duplicates ───────────────────────────────────────────────────────────

n_dup <- sum(duplicated(data))
if (n_dup > 0) {
  cat("\n⚠", n_dup, "duplicate rows detected → removing.\n")
  data <- data %>% distinct()
} else {
  cat("\n✓ No duplicate rows.\n")
}

# ── Build community matrix (sites × species) ───────────────────────────────────

cat("\n=== COMMUNITY MATRIX ===\n")

# Filter zeros, aggregate by site × species
species_col <- intersect(c(SPECIES_COL, "espece", "species"), names(data))[1]
count_col   <- intersect(c(COUNT_COL, "n_ind", "count", "abondance"), names(data))[1]
site_col    <- intersect(c(SITE_COL, "site", "localite"), names(data))[1]

obs_positive <- data %>% filter(.data[[count_col]] > 0)

comm_matrix <- obs_positive %>%
  group_by(across(all_of(c(site_col, species_col)))) %>%
  summarise(total = sum(.data[[count_col]]), .groups = "drop") %>%
  pivot_wider(names_from  = all_of(species_col),
              values_from = total,
              values_fill = 0) %>%
  column_to_rownames(site_col)

cat("Community matrix:", nrow(comm_matrix), "sites ×",
    ncol(comm_matrix), "species\n")

# Verify all numeric
stopifnot("Community matrix must be numeric" =
            all(sapply(comm_matrix, is.numeric)))

# ── Summary stats ──────────────────────────────────────────────────────────────

cat("\n=== DATASET SUMMARY ===\n")
cat("Sites     :", n_distinct(data[[site_col]]), "\n")
cat("Species   :", n_distinct(data[[species_col]]), "\n")
cat("Total N   :", sum(obs_positive[[count_col]]), "individuals\n")
cat("Date range:", as.character(min(data$date, na.rm = TRUE)),
    "→", as.character(max(data$date, na.rm = TRUE)), "\n")

# ── Save processed data ────────────────────────────────────────────────────────

saveRDS(data,         here("data/processed/data_clean.rds"))
saveRDS(comm_matrix,  here("data/processed/comm_matrix.rds"))
write.csv(data, here("data/processed/data_clean.csv"), row.names = FALSE)

cat("\n✓ Saved to data/processed/\n")
cat("  → data_clean.rds (full dataset)\n")
cat("  → comm_matrix.rds (site × species matrix)\n")


