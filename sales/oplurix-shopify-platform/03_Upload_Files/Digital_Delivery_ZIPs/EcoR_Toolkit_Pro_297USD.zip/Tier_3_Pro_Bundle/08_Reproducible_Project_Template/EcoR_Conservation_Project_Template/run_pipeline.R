# ==============================================================================
# EcoR Conservation Project Template - run_pipeline.R
# Sequential runner for the project scripts
# Author: Haja Fabrice RAZAFINDRABE MAMINIAINA
# ==============================================================================
# This runner is intentionally cautious:
#   - run_core()      runs scripts 0, 1, 2, 4, 7 (community ecology workflow)
#   - run_advanced()  also runs 3 (spatial), 5 (SDM), 6 (population/occupancy)
#   - run(c(0, 1, 2)) lets you pick exactly which step IDs to run
#
# Advanced scripts require additional packages and system libraries
# (sf, terra, biomod2, unmarked, etc.). Run 0_setup.R with
# ECOR_INSTALL_ADVANCED <- TRUE before attempting them.
#
# USAGE:
#   source("run_pipeline.R")   # loads helpers, does NOT run anything yet
#   run_core()                  # safe community-ecology workflow
#   run(c(0, 1, 4))             # custom subset by step IDs
#   run_advanced()              # full sequence including advanced scripts
# ==============================================================================

library(here)
if (!requireNamespace("tictoc", quietly = TRUE)) {
  install.packages("tictoc")
}
library(tictoc)

cat("\n=== EcoR Conservation Project Template - Pipeline Runner ===\n\n")

# ── Pipeline definition ───────────────────────────────────────────────────────

PIPELINE <- list(
  list(id = 0, file = "0_setup.R",                     name = "Setup & packages",
       tier = "core"),
  list(id = 1, file = "1_data_import_clean.R",         name = "Data import & cleaning",
       tier = "core"),
  list(id = 2, file = "2_exploratory_analysis.R",      name = "Exploratory analysis",
       tier = "core"),
  list(id = 3, file = "3_spatial_analysis.R",          name = "Spatial analysis & GIS",
       tier = "advanced"),
  list(id = 4, file = "4_biodiversity_metrics.R",      name = "Biodiversity metrics",
       tier = "core"),
  list(id = 5, file = "5_species_distribution.R",      name = "Species distribution modelling",
       tier = "advanced"),
  list(id = 6, file = "6_population_dynamics.R",       name = "Population dynamics & occupancy",
       tier = "advanced"),
  list(id = 7, file = "7_visualization_publication.R", name = "Publication figures",
       tier = "core")
)

# ── Runner ────────────────────────────────────────────────────────────────────

run_step <- function(step) {
  path <- here::here(step$file)
  if (!file.exists(path)) {
    cat("  Skipped: ", step$file, " not found.\n", sep = "")
    return(invisible(NULL))
  }
  cat(sprintf("\n[%d] %s  (%s)\n", step$id, step$name, step$tier))
  tic()
  tryCatch(
    source(path, echo = FALSE),
    error = function(e) {
      toc()
      cat("  ERROR in ", step$file, ":\n  ", conditionMessage(e), "\n", sep = "")
      cat("  Tip: copy the error into the included prompt library to debug.\n")
      stop("Pipeline stopped at step ", step$id, " (", step$file, ").", call. = FALSE)
    }
  )
  toc()
  cat("  Done\n")
}

# Run a specific list of step IDs, e.g. run(c(0, 1, 2))
run <- function(step_ids) {
  if (missing(step_ids) || is.null(step_ids)) {
    stop("Pass a vector of step IDs, e.g. run(c(0, 1, 2)).\n",
         "Use run_core() for the safe default or run_advanced() for everything.")
  }
  for (step in PIPELINE) {
    if (step$id %in% step_ids) run_step(step)
  }
  cat("\nSelected steps complete.\n")
}

# Safe default: community ecology workflow without spatial or SDM
run_core <- function() {
  cat("Running core steps: 0, 1, 2, 4, 7.\n")
  run(c(0, 1, 2, 4, 7))
}

# Everything, including advanced spatial/SDM/population scripts
run_advanced <- function() {
  cat("Running full pipeline including advanced steps 3, 5, 6.\n")
  cat("These require sf, terra, biomod2, unmarked, etc.\n")
  cat("Run 0_setup.R first with ECOR_INSTALL_ADVANCED <- TRUE if needed.\n")
  run(c(0, 1, 2, 3, 4, 5, 6, 7))
}

cat("Loaded run_pipeline.R helpers.\n")
cat("Call run_core() for the safe workflow, run_advanced() for everything,\n")
cat("or run(c(0, 1)) for a custom subset.\n")
