# ==============================================================================
# EcoR Toolkit — functions/utils_figures.R
# Shared ggplot2 theme, colour palettes, and figure export helpers
# Source this file at the top of every script and notebook
# ==============================================================================

library(ggplot2)
library(scales)

# ── EcoR colour palette (Wong 2011 — colourblind-friendly) ────────────────────

ECOR_PALETTE <- c(
  "#0F6E56",  # 1 Teal dark    — primary / intact habitat
  "#1D9E75",  # 2 Teal mid     — secondary
  "#56B4E9",  # 3 Sky blue     — edge / transition
  "#E69F00",  # 4 Orange       — degraded
  "#D55E00",  # 5 Vermilion    — agricultural / disturbed
  "#CC79A7",  # 6 Pink         — additional group
  "#009E73",  # 7 Green        — additional group
  "#F0E442"   # 8 Yellow       — additional group
)

# Named version for habitat types (edit to match your field categories)
ECOR_HABITAT_COLOURS <- c(
  "Primary forest"      = "#0F6E56",
  "Secondary forest"    = "#1D9E75",
  "Forest edge"         = "#56B4E9",
  "Degraded scrubland"  = "#E69F00",
  "Agricultural matrix" = "#D55E00",
  "Savanna"             = "#CC79A7"
)

# ── Publication theme ─────────────────────────────────────────────────────────

theme_ecor <- function(base_size = 12, legend_pos = "bottom") {
  theme_minimal(base_size = base_size) +
    theme(
      # Titles
      plot.title       = element_text(face = "bold", size = base_size + 1,
                                      hjust = 0),
      plot.subtitle    = element_text(color = "grey50", size = base_size - 1,
                                      hjust = 0),
      plot.caption     = element_text(color = "grey60", size = base_size - 3,
                                      hjust = 0),
      # Axes
      axis.text        = element_text(size = base_size - 1),
      axis.title       = element_text(size = base_size - 0.5),
      # Grid — minimal
      panel.grid.minor = element_blank(),
      panel.grid.major = element_line(color = "grey92", linewidth = 0.4),
      # Legend
      legend.position  = legend_pos,
      legend.title     = element_text(face = "bold", size = base_size - 1),
      legend.text      = element_text(size = base_size - 1.5),
      # Facets
      strip.text       = element_text(face = "bold", size = base_size - 0.5),
      strip.background = element_blank()
    )
}

# Set as default
ggplot2::theme_set(theme_ecor())

# ── Figure export ─────────────────────────────────────────────────────────────

#' Save a ggplot figure with EcoR defaults
#' @param fig       A ggplot object
#' @param name      File name without extension (saved as PNG + PDF)
#' @param width     Width in cm (default 18 — typical journal double column)
#' @param height    Height in cm (default 11)
#' @param dpi       Resolution (default 300 — required for most journals)
#' @param units_mm  If TRUE, width/height are in mm instead of cm
#' @param path      Output directory

save_ecor_fig <- function(fig, name,
                           width = 18, height = 11,
                           dpi = 300, units_mm = FALSE,
                           path = here::here("outputs/figures")) {

  dir.create(path, showWarnings = FALSE, recursive = TRUE)

  units <- if (units_mm) "mm" else "cm"

  # PNG (for journal submission)
  png_path <- file.path(path, paste0(name, ".png"))
  ggplot2::ggsave(png_path, fig,
                  width = width, height = height,
                  units = units, dpi = dpi)

  # PDF (vector, for editing in Illustrator / Inkscape)
  pdf_path <- file.path(path, paste0(name, ".pdf"))
  ggplot2::ggsave(pdf_path, fig,
                  width = width, height = height,
                  units = units, device = cairo_pdf)

  message("✓ Saved: ", basename(png_path),
          " (", width, units, " × ", height, units,
          " @ ", dpi, " DPI)")
  invisible(png_path)
}

# ── Quick helpers ─────────────────────────────────────────────────────────────

#' Horizontal barplot with automatic ordering
bar_horizontal <- function(df, x_col, y_col, fill_col = NULL,
                            title = "", x_lab = "", y_lab = NULL) {
  p <- ggplot(df, aes(
    x    = reorder(.data[[x_col]], .data[[y_col]]),
    y    = .data[[y_col]],
    fill = if (!is.null(fill_col)) .data[[fill_col]]
           else .data[[x_col]]
  )) +
    geom_col(width = 0.65) +
    geom_text(aes(label = round(.data[[y_col]], 1)),
              hjust = -0.3, size = 3.2, fontface = "bold") +
    coord_flip() +
    scale_fill_manual(values = ECOR_PALETTE, guide = "none") +
    scale_y_continuous(expand = expansion(mult = c(0, 0.15))) +
    labs(title = title, x = y_lab, y = x_lab) +
    theme_ecor()
  p
}

#' Boxplot with jitter overlay (standard for ecology papers)
box_jitter <- function(df, x_col, y_col, fill_col = x_col,
                        y_lab = y_col, title = "") {
  ggplot(df, aes(
    x    = .data[[x_col]],
    y    = .data[[y_col]],
    fill = .data[[fill_col]]
  )) +
    geom_boxplot(width = 0.55, outlier.shape = NA, alpha = 0.85) +
    geom_jitter(width = 0.12, size = 2, alpha = 0.55) +
    scale_fill_manual(values = ECOR_PALETTE, guide = "none") +
    labs(title = title, x = NULL, y = y_lab) +
    theme_ecor()
}

#' Coefficient plot (for lm / lmer model outputs)
coef_plot <- function(coef_df,
                       term_col = "term", est_col = "estimate",
                       lo_col = "conf.low", hi_col = "conf.high",
                       p_col = "p.value", title = "Model coefficients") {
  coef_df %>%
    dplyr::filter(!grepl("Intercept", .data[[term_col]])) %>%
    dplyr::mutate(
      sig   = .data[[p_col]] < 0.05,
      color = dplyr::case_when(
        .data[[est_col]] > 0 & sig ~ "Positive",
        .data[[est_col]] < 0 & sig ~ "Negative",
        TRUE                       ~ "n.s."
      )
    ) %>%
    ggplot(aes(
      x    = reorder(.data[[term_col]], .data[[est_col]]),
      y    = .data[[est_col]],
      color = color,
      ymin  = .data[[lo_col]],
      ymax  = .data[[hi_col]]
    )) +
    geom_hline(yintercept = 0, linetype = "dashed", color = "grey60") +
    geom_errorbar(width = 0.3, linewidth = 1) +
    geom_point(size = 3.5) +
    coord_flip() +
    scale_color_manual(
      values = c("Positive" = "#0F6E56",
                 "Negative" = "#D55E00",
                 "n.s."     = "grey60"),
      name = "Effect"
    ) +
    labs(title = title, x = NULL, y = "Coefficient (β) ± 95% CI") +
    theme_ecor()
}

