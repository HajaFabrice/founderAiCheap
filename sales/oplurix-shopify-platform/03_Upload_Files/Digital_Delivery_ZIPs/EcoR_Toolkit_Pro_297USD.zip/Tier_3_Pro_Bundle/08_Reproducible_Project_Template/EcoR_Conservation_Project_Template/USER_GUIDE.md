# EcoR Conservation Project Template - User Guide

## Quick Reference

| Task | Where to go |
|---|---|
| First setup | `source("0_setup.R")` |
| Test with included data | `source("1_data_import_clean.R")` |
| Safe core workflow | `source("run_pipeline.R"); run_core()` |
| Full pipeline (advanced) | `source("run_pipeline.R"); run_advanced()` |
| Custom step subset | `run(c(0, 1, 4))` |
| Community ecology notebook | `notebooks/Module1_Analyse_Transects_Herp_Madagascar.Rmd` |
| Behavioural ecology notebook | `notebooks/Module2_Behavioural_Ecology_Zonosaurus.Rmd` |
| Ecophysiology notebook | `notebooks/Module3_Ecophysiology_Amphibians.Rmd` |
| Population genetics notebook | `notebooks/Module4_Population_Genetics.Rmd` |
| Functional morphology notebook | `notebooks/Module5_Functional_Morphology.Rmd` |
| Advanced: spatial | `3_spatial_analysis.R` |
| Advanced: SDM | `5_species_distribution.R` |
| Advanced: occupancy / camera trap | `6_population_dynamics.R` |
| Publication figures | `7_visualization_publication.R` |
| Reproducible pipeline | `library(targets); tar_make()` |

## First Run

Open `EcoR_Conservation_Project_Template.Rproj` in RStudio, then run:

```r
source("0_setup.R")
source("1_data_import_clean.R")
```

The default import script uses `data/raw/TEMPLATE_transect_survey.csv`, so you
can confirm the workflow runs end-to-end before adding your own data.

## Using Your Own Data

1. Copy one of the templates in `data/raw/`.
2. Rename the copy for your project.
3. Edit `DATA_FILE`, `DATE_COL`, `SITE_COL`, `SPECIES_COL`, and `COUNT_COL` at
   the top of `1_data_import_clean.R`.
4. Run `source("1_data_import_clean.R")`.

## Suggested Workflows

Core community ecology (safe on most machines):

```r
source("1_data_import_clean.R")
source("2_exploratory_analysis.R")
source("4_biodiversity_metrics.R")
source("7_visualization_publication.R")
```

Run that sequence with one call:

```r
source("run_pipeline.R")
run_core()
```

Advanced full pipeline (only after the advanced packages and system libraries
are installed):

```r
ECOR_INSTALL_ADVANCED <- TRUE
source("0_setup.R")
source("run_pipeline.R")
run_advanced()
```

Reproducible pipeline (core workflow only):

```r
install.packages(c("targets", "tarchetypes"))
library(targets)
tar_make()
```

Review `_targets.R` before using `targets` with your own data.

## Advanced Workflows and Dependencies

The advanced scripts and packages are clearly labelled and are NOT enabled by
default:

- `3_spatial_analysis.R` needs `sf`, `terra`, `tmap`, `ggspatial`, and may
  download CHELSA layers via `geodata`.
- `5_species_distribution.R` needs `biomod2`, `dismo`, `ENMeval`, and an
  internet connection for climate data.
- `6_population_dynamics.R` needs `unmarked` and detection-history data.

Each of these has system-library dependencies (GDAL, GEOS, PROJ, sometimes
Java) that R cannot install for you. Treat them as optional, dependency-heavy
extensions rather than guaranteed-to-run scripts.

For a fast first success, test scripts 1, 2, 4, and 7 before attempting the
advanced scripts.

## Getting Help from AI

Use `prompts/50_Prompts_Biodiversity_R.md` for debugging, analysis planning,
figure improvements, and Methods/Results drafting. Use
`prompts/Prompt_Chaining_System.html` when you want a step-by-step writing
workflow.

## Support Boundary

This template accelerates analysis. It is not a custom consulting service.
Always check that your statistical method matches your sampling design, and
verify advanced spatial/SDM outputs with a domain specialist before using them
in a thesis, report, or manuscript.
