# ==============================================================================
# EcoR Toolkit — 4_biodiversity_metrics.R
# Diversity indices, rarefaction, community comparisons
# Links directly to: notebooks/Module1_Analyse_Transects_Herp_Madagascar.Rmd
# ==============================================================================
# This script runs the core biodiversity analyses in script form.
# For the FULLY ANNOTATED, pedagogical version with figures and
# biological interpretations → open notebooks/Module1_Analyse_Transects_Herp_Madagascar.Rmd
# ==============================================================================

library(here); library(vegan); library(iNEXT)
library(dplyr); library(ggplot2); library(knitr)

source(here("functions/utils_diversity.R"))
source(here("functions/utils_figures.R"))

cat("=== 4. BIODIVERSITY METRICS ===\n")
cat("    (Full annotated version: notebooks/Module1_Analyse_Transects_Herp_Madagascar.Rmd)\n\n")

data        <- readRDS(here("data/processed/data_clean.rds"))
comm_matrix <- readRDS(here("data/processed/comm_matrix.rds"))
site_summary <- readRDS(here("data/processed/site_summary.rds"))

# Detect grouping variable
grp_col <- detect_col(data, c("habitat","habitat_type","group","site"))

# ── 4.1 Alpha diversity indices ────────────────────────────────────────────────

cat("--- 4.1 Alpha diversity ---\n")

alpha_div <- data.frame(
  site     = rownames(comm_matrix),
  S        = vegan::specnumber(comm_matrix),
  N        = rowSums(comm_matrix),
  H        = round(vegan::diversity(comm_matrix, "shannon"), 3),
  D        = round(vegan::diversity(comm_matrix, "simpson"), 3),
  J        = round(vegan::diversity(comm_matrix, "shannon") /
                   log(vegan::specnumber(comm_matrix)), 3),
  stringsAsFactors = FALSE
) %>%
  mutate(J = ifelse(is.nan(J), NA, J))

# Chao1 and ACE
rich_est  <- t(vegan::estimateR(comm_matrix))
alpha_div$Chao1 <- round(rich_est[, "S.chao1"], 1)
alpha_div$ACE   <- round(rich_est[, "S.ACE"], 1)

print(alpha_div)
write.csv(alpha_div, here("outputs/tables/alpha_diversity.csv"),
          row.names = FALSE)

# ── 4.2 Normality → choose correct test ───────────────────────────────────────

cat("\n--- 4.2 Normality test (determines which stats to use) ---\n")

if (nrow(alpha_div) >= 3 && nrow(alpha_div) <= 5000) {
  sw_H <- shapiro.test(alpha_div$H)
  normal <- sw_H$p.value > 0.05
  cat(sprintf("Shapiro-Wilk on H': W = %.4f, p = %.4f → %s\n",
              sw_H$statistic, sw_H$p.value,
              ifelse(normal, "NORMAL → ANOVA + Tukey",
                             "NON-NORMAL → Kruskal-Wallis + Dunn")))
} else {
  normal <- FALSE
  cat(sprintf("Shapiro-Wilk on H' skipped: needs 3-5000 sites, found %d.\n",
              nrow(alpha_div)))
}

# ── 4.3 Statistical test ──────────────────────────────────────────────────────

cat("\n--- 4.3 Between-group comparison ---\n")

# Attach habitat info
if (grp_col %in% names(data)) {
  habitat_map <- data %>%
    group_by(site) %>%
    summarise(habitat = first(.data[[grp_col]]), .groups = "drop")
  alpha_div <- left_join(alpha_div, habitat_map, by = "site")
}

if ("habitat" %in% names(alpha_div) && n_distinct(alpha_div$habitat) > 1) {
  if (normal) {
    model <- aov(H ~ habitat, data = alpha_div)
    cat("ANOVA results:\n")
    print(summary(model))
    cat("\nTukey post-hoc:\n")
    print(TukeyHSD(model))
  } else {
    kw <- kruskal.test(H ~ habitat, data = alpha_div)
    cat(sprintf("Kruskal-Wallis: H = %.2f, df = %d, p = %.4f\n",
                kw$statistic, kw$parameter, kw$p.value))
    if (kw$p.value < 0.05 && requireNamespace("dunn.test", quietly = TRUE)) {
      cat("\nDunn post-hoc (Bonferroni):\n")
      dunn.test::dunn.test(alpha_div$H, alpha_div$habitat,
                           method = "bonferroni", kw = FALSE)
    }
  }
}

# ── 4.4 Rarefaction curves (iNEXT) ────────────────────────────────────────────

cat("\n--- 4.4 Rarefaction / extrapolation ---\n")

abund_list <- lapply(seq_len(nrow(comm_matrix)), function(i) {
  v <- as.numeric(comm_matrix[i, ])
  v[v > 0]
})
names(abund_list) <- rownames(comm_matrix)

inext_out <- iNEXT(abund_list, q = 0, datatype = "abundance",
                   nboot = 100, se = TRUE)

# Asymptotic richness
cat("\nAsymptotic richness estimates:\n")
print(inext_out$AsyEst %>%
        dplyr::filter(Diversity == "Species richness") %>%
        dplyr::select(Assemblage, Observed, Estimator, LCL, UCL))

fig_rare <- ggiNEXT(inext_out, type = 1, se = TRUE) +
  scale_color_manual(values = ECOR_PALETTE) +
  scale_fill_manual(values  = ECOR_PALETTE) +
  labs(title    = "Species accumulation curves",
       subtitle = "Rarefaction (solid) · Extrapolation (dashed) · 95% CI",
       x = "Number of individuals", y = "Species richness") +
  theme_ecor()

save_ecor_fig(fig_rare, "fig1_rarefaction", width = 18, height = 11)

# ── 4.5 Beta diversity ────────────────────────────────────────────────────────

cat("\n--- 4.5 Beta diversity ---\n")

if (requireNamespace("betapart", quietly = TRUE)) {
  beta <- betapart::beta.pair(comm_matrix > 0, index.family = "sorensen")
  cat("Beta diversity (Sorensen):\n")
  cat("  Total (Sor) :   ", round(mean(as.matrix(beta$beta.sor)[lower.tri(as.matrix(beta$beta.sor))]), 3), "\n")
  cat("  Turnover (Sim): ", round(mean(as.matrix(beta$beta.sim)[lower.tri(as.matrix(beta$beta.sim))]), 3), "\n")
  cat("  Nestedness:     ", round(mean(as.matrix(beta$beta.sne)[lower.tri(as.matrix(beta$beta.sne))]), 3), "\n")
}

# ── 4.6 Save ──────────────────────────────────────────────────────────────────

saveRDS(alpha_div, here("data/processed/alpha_diversity.rds"))
saveRDS(inext_out, here("data/processed/inext_results.rds"))

cat("\n✓ Biodiversity metrics complete.\n")
cat("  → alpha_diversity.rds | inext_results.rds\n")
cat("  → For full annotated walkthrough: notebooks/Module1_Analyse_Transects_Herp_Madagascar.Rmd\n")

