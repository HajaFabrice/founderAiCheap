# ==============================================================================
# EcoR Toolkit — functions/utils_diversity.R
# Reusable diversity analysis functions
# ==============================================================================

library(vegan)

# ── Full alpha diversity table ─────────────────────────────────────────────────
#' Compute all alpha diversity indices in one call
#' @param comm  Site × species matrix (rows = sites, columns = species)
#' @return      Dataframe with S, N, H', D, J', Chao1, ACE per site

alpha_diversity_table <- function(comm) {
  comm <- as.matrix(comm)

  rich_est <- t(estimateR(comm))

  df <- data.frame(
    site     = rownames(comm),
    S        = specnumber(comm),
    N        = rowSums(comm),
    H        = round(diversity(comm, "shannon"),   3),
    D        = round(diversity(comm, "simpson"),   3),
    InvD     = round(diversity(comm, "invsimpson"),3),
    J        = round(diversity(comm, "shannon") /
                     log(specnumber(comm)), 3),
    Margalef = round((specnumber(comm) - 1) /
                     log(rowSums(comm)), 3),
    Chao1    = round(rich_est[, "S.chao1"], 1),
    ACE      = round(rich_est[, "S.ACE"],   1),
    stringsAsFactors = FALSE
  ) %>%
    dplyr::mutate(
      J        = ifelse(is.nan(J), NA, J),
      Margalef = ifelse(is.infinite(Margalef) | is.nan(Margalef), NA, Margalef)
    )

  df
}

# ── Pairwise FST (wrapper) ─────────────────────────────────────────────────────
#' Compute and tidy pairwise Weir & Cockerham FST
#' Requires: hierfstat package
pairwise_fst_tidy <- function(gen_obj) {
  if (!requireNamespace("hierfstat", quietly = TRUE))
    stop("Package 'hierfstat' required. Install with install.packages('hierfstat')")
  mat <- hierfstat::pairwise.WCfst(gen_obj)
  mat[lower.tri(mat)] <- t(mat)[lower.tri(mat)]
  diag(mat) <- 0
  round(mat, 4)
}

# ── Beta diversity decomposition ──────────────────────────────────────────────
#' Compute Sorensen beta diversity decomposed into turnover + nestedness
#' Requires: betapart package
beta_decompose <- function(comm) {
  if (!requireNamespace("betapart", quietly = TRUE))
    stop("Package 'betapart' required.")
  pa <- comm > 0
  beta <- betapart::beta.pair(pa, index.family = "sorensen")
  list(
    total      = as.matrix(beta$beta.sor),
    turnover   = as.matrix(beta$beta.sim),
    nestedness = as.matrix(beta$beta.sne)
  )
}

# ── iNEXT wrapper ─────────────────────────────────────────────────────────────
#' Run iNEXT from a community matrix (no list prep needed)
run_inext <- function(comm, q = 0, nboot = 200) {
  if (!requireNamespace("iNEXT", quietly = TRUE))
    stop("Package 'iNEXT' required.")

  abund_list <- lapply(seq_len(nrow(comm)), function(i) {
    v <- as.numeric(comm[i, ])
    v[v > 0]
  })
  names(abund_list) <- rownames(comm)

  iNEXT::iNEXT(abund_list, q = q, datatype = "abundance",
               nboot = nboot, se = TRUE)
}

# ── NMDS + PERMANOVA wrapper ──────────────────────────────────────────────────
#' Run full multivariate analysis: betadisper → PERMANOVA → NMDS
#' @param comm   Site × species matrix
#' @param groups Factor vector of group labels (same order as rows of comm)
#' @return       Named list: nmds, permanova, betadisper, anosim

multivariate_analysis <- function(comm, groups) {
  bray <- vegan::vegdist(comm, method = "bray")

  # 1. Homogeneity of dispersion (must check BEFORE PERMANOVA)
  disp      <- vegan::betadisper(bray, groups)
  disp_perm <- vegan::permutest(disp, permutations = 999)

  # 2. PERMANOVA
  env_df <- data.frame(group = groups)
  perm   <- vegan::adonis2(comm ~ group, data = env_df,
                            method = "bray", permutations = 999)

  # 3. ANOSIM
  ano <- vegan::anosim(bray, groups, permutations = 999)

  # 4. NMDS
  nmds <- vegan::metaMDS(comm, distance = "bray", k = 2,
                          trymax = 100, trace = FALSE)

  # Report
  cat("=== MULTIVARIATE ANALYSIS ===\n")
  cat(sprintf("betadisper: F = %.2f, p = %.3f %s\n",
              disp_perm$tab[1,"F"], disp_perm$tab[1,"Pr(>F)"],
              ifelse(disp_perm$tab[1,"Pr(>F)"] > 0.05,
                     "✓ Homogeneous — PERMANOVA valid",
                     "⚠ Heterogeneous — interpret PERMANOVA carefully")))
  cat(sprintf("PERMANOVA:  F = %.2f, R² = %.3f, p = %.3f\n",
              perm[1,"F"], perm[1,"R2"], perm[1,"Pr(>F)"]))
  cat(sprintf("ANOSIM:     R = %.3f, p = %.3f\n",
              ano$statistic, ano$signif))
  cat(sprintf("NMDS stress: %.3f %s\n",
              nmds$stress,
              ifelse(nmds$stress < 0.1, "(excellent)",
              ifelse(nmds$stress < 0.2, "(good)", "(check k)"))))

  invisible(list(
    nmds      = nmds,
    permanova = perm,
    betadisper = list(result = disp, test = disp_perm),
    anosim    = ano
  ))
}

# ── Auto statistical test ──────────────────────────────────────────────────────
#' Choose and run the correct test (ANOVA or Kruskal-Wallis) based on normality
#' @param df       Dataframe with response and group columns
#' @param y_col    Name of the response variable column
#' @param grp_col  Name of the grouping variable column
#' @return         Test result object + printed interpretation

auto_test <- function(df, y_col, grp_col) {
  y   <- df[[y_col]]
  grp <- df[[grp_col]]

  # Normality
  sw      <- shapiro.test(y)
  normal  <- sw$p.value > 0.05

  cat(sprintf("Shapiro-Wilk: W = %.4f, p = %.4f → %s\n",
              sw$statistic, sw$p.value,
              ifelse(normal, "Normal", "Non-normal")))

  if (normal) {
    # Homoscedasticity
    lev <- car::leveneTest(y ~ grp)
    cat(sprintf("Levene: F = %.3f, p = %.4f → %s\n",
                lev[1,"F value"], lev[1,"Pr(>F)"],
                ifelse(lev[1,"Pr(>F)"] > 0.05,
                       "Homogeneous variances → ANOVA",
                       "Heterogeneous → Welch ANOVA")))

    result <- aov(reformulate(grp_col, y_col), data = df)
    cat("\nANOVA:\n"); print(summary(result))
  } else {
    result <- kruskal.test(df[[y_col]] ~ df[[grp_col]])
    cat(sprintf("\nKruskal-Wallis: H = %.3f, df = %d, p = %.4f\n",
                result$statistic, result$parameter, result$p.value))

    if (result$p.value < 0.05 &&
        requireNamespace("dunn.test", quietly = TRUE)) {
      cat("\nDunn post-hoc (Bonferroni):\n")
      dunn.test::dunn.test(y, grp, method = "bonferroni", kw = FALSE)
    }
  }

  invisible(result)
}

