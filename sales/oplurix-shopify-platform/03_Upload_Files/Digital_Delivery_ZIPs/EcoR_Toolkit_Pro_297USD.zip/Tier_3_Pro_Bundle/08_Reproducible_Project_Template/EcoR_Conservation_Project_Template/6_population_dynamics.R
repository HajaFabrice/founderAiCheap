# ==============================================================================
# EcoR Toolkit — 6_population_dynamics.R
# Occupancy models · Capture-recapture · PVA · Camera trap
# Links to: notebooks/Module2_Behavioural_Ecology_Zonosaurus.Rmd
# ==============================================================================

library(here); library(dplyr); library(unmarked); library(ggplot2)

source(here("functions/utils_figures.R"))

cat("=== 6. POPULATION DYNAMICS & OCCUPANCY ===\n\n")

# ── 6.1 Detection/non-detection data structure ─────────────────────────────────

cat("--- 6.1 Detection history format ---\n")
cat("Required format: sites x visits matrix (1=detected, 0=not detected, NA=not surveyed)\n\n")

# Demo detection history (Zonosaurus karsteni, Kirindy, 3 visits per site)
set.seed(42)
n_sites  <- 20
n_visits <- 3

# True occupancy prob = 0.7 | Detection prob = 0.5
psi_true <- 0.7
p_true   <- 0.5

z   <- rbinom(n_sites, 1, psi_true)  # true presence
det <- matrix(
  rbinom(n_sites * n_visits, 1, p_true * z),
  nrow = n_sites, ncol = n_visits
)
rownames(det) <- paste0("Site_", sprintf("%02d", 1:n_sites))
colnames(det) <- paste0("Visit_", 1:n_visits)

# Site covariates
site_covs <- data.frame(
  habitat   = sample(c("Primary","Secondary","Degraded"), n_sites, replace = TRUE),
  canopy    = round(runif(n_sites, 20, 90), 1),
  altitude  = round(rnorm(n_sites, 350, 80))
)

# Observation covariates (one value per site-visit)
obs_covs <- list(
  temp = matrix(round(rnorm(n_sites * n_visits, 28, 3), 1),
                nrow = n_sites, ncol = n_visits),
  time = matrix(sample(c("AM","PM"), n_sites * n_visits, replace = TRUE),
                nrow = n_sites, ncol = n_visits)
)

cat("Detection history (first 5 sites):\n")
print(det[1:5, ])
cat("\nNaive occupancy (% sites with ≥1 detection):",
    round(mean(rowSums(det) > 0) * 100, 1), "%\n")
cat("True occupancy (model will estimate):", psi_true * 100, "%\n\n")

# ── 6.2 Format for unmarked ───────────────────────────────────────────────────

cat("--- 6.2 Occupancy model (single-season) ---\n")

# Format with unmarked
umf <- unmarkedFrameOccu(
  y         = det,
  siteCovs  = site_covs,
  obsCovs   = list(temp = obs_covs$temp)
)

# Null model
m0 <- occu(~ 1 ~ 1, data = umf)

# Habitat model
m1 <- occu(~ temp ~ habitat, data = umf)

# Habitat + canopy
m2 <- occu(~ temp ~ habitat + canopy, data = umf)

# Model selection
cat("\nModel comparison (AIC):\n")
ms <- fitList(
  "psi(.) p(.)"           = m0,
  "psi(habitat) p(temp)"  = m1,
  "psi(habitat+canopy) p(temp)" = m2
)
print(modSel(ms))

# Best model estimates
cat("\nBest model parameter estimates:\n")
print(summary(m1))

# Back-transform occupancy and detection
cat("\nOccupancy (psi) by habitat:\n")
newdata_psi <- data.frame(
  habitat = c("Primary","Secondary","Degraded"),
  canopy  = mean(site_covs$canopy)
)
psi_pred <- predict(m1, type = "state", newdata = newdata_psi)
print(round(psi_pred, 3))

# ── 6.3 Camera trap analysis ──────────────────────────────────────────────────

cat("\n--- 6.3 Camera trap analysis ---\n")
cat("For camera trap data (CSV from CamtrapR or TIMELAPSE):\n\n")

cat('
library(camtrapR)

# Load camera records
cam_records <- read.csv("data/raw/camera_records.csv")

# Create detection history (species-level)
det_hist <- detectionHistory(
  recordTable   = cam_records,
  camOp          = camera_operation_matrix,
  stationCol     = "Station",
  speciesCol     = "Species",
  recordDateTimeCol = "DateTimeOriginal",
  species        = "Zonosaurus_karsteni",
  occasionLength = 7,  # 7-day occasions
  day1           = "survey",
  includeEffort  = TRUE,
  timeZone       = "Indian/Antananarivo"
)

# Occupancy model
umf_cam <- unmarkedFrameOccu(
  y       = det_hist$detection_history,
  siteCovs = site_data
)
m_cam <- occu(~ effort ~ habitat, data = umf_cam)
')

# ── 6.4 Occupancy map ─────────────────────────────────────────────────────────

cat("\n--- 6.4 Occupancy predictions ---\n")

# Plot predicted occupancy by habitat
fig_occ <- data.frame(
  habitat     = newdata_psi$habitat,
  psi         = psi_pred$Predicted,
  psi_lower   = psi_pred$lower,
  psi_upper   = psi_pred$upper
) %>%
  ggplot(aes(x = reorder(habitat, psi), y = psi,
             color = habitat, ymin = psi_lower, ymax = psi_upper)) +
  geom_pointrange(size = 1.2, linewidth = 1) +
  geom_hline(yintercept = mean(backTransform(m0, "state")@estimates),
             linetype = "dashed", color = "grey50") +
  scale_color_manual(values = ECOR_PALETTE, guide = "none") +
  scale_y_continuous(labels = scales::percent_format(), limits = c(0, 1)) +
  labs(
    title    = "Predicted occupancy by habitat",
    subtitle = paste0("Single-season occupancy model · ",
                      n_sites, " sites · ", n_visits, " visits"),
    x        = NULL,
    y        = "Occupancy probability (ψ ± 95% CI)",
    caption  = "Dashed = null model estimate"
  ) +
  theme_ecor()

save_ecor_fig(fig_occ, "fig_occupancy_by_habitat", width = 12, height = 8)
cat("✓ Occupancy figure saved.\n")

# ── 6.5 Save outputs ─────────────────────────────────────────────────────────

saveRDS(m1, here("outputs/models/occupancy_m1.rds"))
saveRDS(psi_pred, here("data/processed/occupancy_predictions.rds"))

cat("\n✓ Population dynamics complete.\n")
cat("  → Behavioural/individual analyses: notebooks/Module2_Behavioural_Ecology_Zonosaurus.Rmd\n")
cat("  → Ecophysiology: notebooks/Module3_Ecophysiology_Amphibians.Rmd\n")

