# ==============================================================================
# EcoR Toolkit — functions/utils_data.R
# Reusable data helpers used across all scripts and notebooks
# ==============================================================================

# ── Column detection helper ────────────────────────────────────────────────────
#' Detect the first matching column name from a list of candidates
#' @param df   A dataframe
#' @param candidates  Character vector of possible column names (in priority order)
#' @return The first matching column name, or NULL if none found

detect_col <- function(df, candidates) {
  match <- intersect(candidates, names(df))
  if (length(match) == 0) return(NULL)
  match[1]
}

# ── Safe read ─────────────────────────────────────────────────────────────────
#' Import CSV or Excel — auto-detects format
safe_read <- function(path) {
  ext <- tools::file_ext(path)
  switch(ext,
    "csv"  = readr::read_csv(path, show_col_types = FALSE),
    "xlsx" = readxl::read_excel(path),
    "xls"  = readxl::read_excel(path),
    "rds"  = readRDS(path),
    stop("Unsupported format: .", ext)
  )
}

# ── Build community matrix ─────────────────────────────────────────────────────
#' Convert long-format observation data to site × species matrix
#' @param df          Long-format dataframe
#' @param site_col    Name of site column
#' @param species_col Name of species column
#' @param count_col   Name of count/abundance column
#' @return Matrix with sites as rows, species as columns

build_comm_matrix <- function(df, site_col = "site",
                               species_col = "espece",
                               count_col = "n_ind") {
  df %>%
    dplyr::filter(.data[[count_col]] > 0) %>%
    dplyr::group_by(.data[[site_col]], .data[[species_col]]) %>%
    dplyr::summarise(total = sum(.data[[count_col]]), .groups = "drop") %>%
    tidyr::pivot_wider(
      names_from  = species_col,
      values_from = "total",
      values_fill = 0
    ) %>%
    tibble::column_to_rownames(site_col) %>%
    as.data.frame()
}

# ── Validate community matrix ─────────────────────────────────────────────────
validate_comm <- function(comm) {
  stopifnot(
    "Must be a data.frame or matrix"  = is.data.frame(comm) || is.matrix(comm),
    "All values must be numeric"      = all(sapply(comm, is.numeric)),
    "No negative values allowed"      = all(comm >= 0, na.rm = TRUE),
    "Must have at least 2 sites"      = nrow(comm) >= 2,
    "Must have at least 2 species"    = ncol(comm) >= 2
  )
  invisible(comm)
}

# ── Summary table ─────────────────────────────────────────────────────────────
#' Quick summary per site — S, N, density, transects
site_summary_table <- function(df, site_col = "site",
                                species_col = "espece",
                                count_col = "n_ind",
                                transect_col = NULL,
                                transect_length_m = 200) {
  grp_vars <- c(site_col)
  if (!is.null(transect_col)) grp_vars <- c(grp_vars, transect_col)

  df %>%
    dplyr::filter(.data[[count_col]] > 0) %>%
    dplyr::group_by(dplyr::across(dplyr::all_of(site_col))) %>%
    dplyr::summarise(
      S          = dplyr::n_distinct(.data[[species_col]]),
      N          = sum(.data[[count_col]]),
      n_transects = if (!is.null(transect_col))
                     dplyr::n_distinct(.data[[transect_col]]) else NA_integer_,
      .groups    = "drop"
    ) %>%
    dplyr::mutate(
      density_100m = dplyr::if_else(
        !is.na(n_transects),
        round(N / (n_transects * transect_length_m) * 100, 2),
        NA_real_
      )
    )
}

# ── Shapiro auto-report ────────────────────────────────────────────────────────
#' Run Shapiro-Wilk and print interpretation
shapiro_report <- function(x, var_name = "variable") {
  if (length(x) < 3)  { cat("⚠ n < 3 — cannot test normality.\n"); return(invisible(NULL)) }
  if (length(x) > 5000) x <- sample(x, 5000)
  sw <- shapiro.test(x)
  cat(sprintf(
    "Shapiro-Wilk (%s): W = %.4f, p = %.4f → %s\n",
    var_name, sw$statistic, sw$p.value,
    ifelse(sw$p.value > 0.05,
           "Normal → parametric tests applicable",
           "Non-normal → use Kruskal-Wallis / Spearman")
  ))
  invisible(sw)
}

# ── Safe merge sites + environment ─────────────────────────────────────────────
#' Merge community data with environmental variables, reporting missing sites
merge_env <- function(div_df, env_df, by_col = "site") {
  merged <- dplyr::left_join(div_df, env_df, by = by_col)
  n_missing <- sum(is.na(merged[[names(env_df)[2]]]))
  if (n_missing > 0)
    message("⚠ ", n_missing, " sites in diversity data have no environmental data.")
  merged
}

# ── Export helper ─────────────────────────────────────────────────────────────
#' Save a dataframe as both .rds and .csv
save_table <- function(df, name, path = here::here("outputs/tables")) {
  saveRDS(df, file.path(path, paste0(name, ".rds")))
  write.csv(df, file.path(path, paste0(name, ".csv")), row.names = FALSE)
  message("✓ Saved: ", name, ".rds + .csv")
}

