# ==============================================================================
# EcoR Toolkit — 7_visualization_publication.R
# Assemble all publication figures + final export
# Run AFTER all analysis scripts have completed
# ==============================================================================

library(here); library(ggplot2); library(patchwork); library(dplyr)

source(here("functions/utils_figures.R"))

cat("=== 7. PUBLICATION FIGURES ===\n\n")

# ── Load all analysis outputs ─────────────────────────────────────────────────

alpha_div <- tryCatch(readRDS(here("data/processed/alpha_diversity.rds")), error = function(e) NULL)
inext_out <- tryCatch(readRDS(here("data/processed/inext_results.rds")),  error = function(e) NULL)
site_sum  <- tryCatch(readRDS(here("data/processed/site_summary.rds")),   error = function(e) NULL)
occ_pred_file <- here("data/processed/occupancy_predictions.rds")
occ_pred  <- if (file.exists(occ_pred_file)) readRDS(occ_pred_file) else NULL

# ── Figure 1: Rarefaction curves ─────────────────────────────────────────────

if (!is.null(inext_out)) {
  fig1 <- iNEXT::ggiNEXT(inext_out, type = 1, se = TRUE) +
    scale_color_manual(values = ECOR_PALETTE) +
    scale_fill_manual(values  = ECOR_PALETTE) +
    labs(title    = "Species accumulation curves",
         subtitle = "Rarefaction · Extrapolation · 95% CI",
         x = "Individuals sampled", y = "Species richness") +
    theme_ecor()
  save_ecor_fig(fig1, "fig1_rarefaction_final", width = 18, height = 11)
  cat("✓ Figure 1 saved.\n")
}

# ── Figure 2: Diversity comparison ────────────────────────────────────────────

if (!is.null(alpha_div) && "habitat" %in% names(alpha_div)) {
  fig2 <- alpha_div %>%
    ggplot(aes(x = reorder(habitat, H), y = H, fill = habitat)) +
    geom_boxplot(width = 0.55, outlier.shape = NA, alpha = 0.85) +
    geom_jitter(width = 0.12, size = 2, alpha = 0.6) +
    scale_fill_manual(values = ECOR_PALETTE, guide = "none") +
    scale_y_continuous(breaks = seq(0, 4, by = 0.5)) +
    labs(title    = "Shannon diversity by habitat",
         subtitle = "H' ± interquartile range · Points = individual sites",
         x = NULL, y = "Shannon diversity (H')") +
    theme_ecor()
  save_ecor_fig(fig2, "fig2_diversity_final", width = 14, height = 10)
  cat("✓ Figure 2 saved.\n")
}

# ── Figure 3: NMDS ordination ─────────────────────────────────────────────────

comm_matrix <- tryCatch(readRDS(here("data/processed/comm_matrix.rds")), error = function(e) NULL)

if (!is.null(comm_matrix) && nrow(comm_matrix) >= 3) {
  nmds <- vegan::metaMDS(comm_matrix, distance = "bray", k = 2,
                          trymax = 100, trace = FALSE)
  cat(sprintf("NMDS stress: %.3f\n", nmds$stress))

  nmds_df <- as.data.frame(vegan::scores(nmds, "sites"))
  nmds_df$site <- rownames(nmds_df)

  if (!is.null(alpha_div) && "habitat" %in% names(alpha_div)) {
    nmds_df <- left_join(nmds_df, alpha_div[, c("site","habitat")], by = "site")
  }

  fig3 <- ggplot(nmds_df, aes(NMDS1, NMDS2)) +
    { if ("habitat" %in% names(nmds_df))
        list(
          stat_ellipse(aes(color = habitat, fill = habitat),
                       geom = "polygon", alpha = 0.1, linewidth = 0.8),
          geom_point(aes(color = habitat), size = 3.5, alpha = 0.85),
          scale_color_manual(values = ECOR_PALETTE, name = "Habitat"),
          scale_fill_manual(values  = ECOR_PALETTE, guide = "none")
        ) else
        list(geom_point(size = 3, color = ECOR_PALETTE[1]))
    } +
    ggrepel::geom_text_repel(aes(label = site), size = 2.8,
                              color = "grey40", max.overlaps = 8) +
    annotate("text",
             x = min(nmds_df$NMDS1, na.rm = TRUE) + 0.01,
             y = max(nmds_df$NMDS2, na.rm = TRUE),
             label = sprintf("Stress = %.3f", nmds$stress),
             hjust = 0, size = 3.5, color = "grey40") +
    labs(title    = "Community composition (NMDS)",
         subtitle = "Bray-Curtis · 95% ellipses per habitat",
         x = "NMDS1", y = "NMDS2") +
    theme_ecor()

  save_ecor_fig(fig3, "fig3_nmds_final", width = 14, height = 11)
  cat("✓ Figure 3 saved.\n")
}

# ── Figure 4: SIMPER top species ─────────────────────────────────────────────

if (!is.null(comm_matrix) && nrow(comm_matrix) >= 3 && !is.null(alpha_div) && "habitat" %in% names(alpha_div)) {
  grp <- alpha_div$habitat[match(rownames(comm_matrix), alpha_div$site)]

  if (!any(is.na(grp)) && n_distinct(grp) > 1 && min(table(grp)) >= 2) {
    simp <- vegan::simper(comm_matrix, grp)
    simp_df <- as.data.frame(summary(simp)[[1]]) %>%
      tibble::rownames_to_column("species") %>%
      slice_max(average, n = 10)

    fig4 <- simp_df %>%
      ggplot(aes(x = reorder(species, average),
                 y = average * 100, fill = cumsum)) +
      geom_col(width = 0.7) +
      coord_flip() +
      scale_fill_gradient(low = ECOR_PALETTE[2], high = ECOR_PALETTE[1],
                          name = "Cumulative\ncontrib.") +
      scale_x_discrete(labels = function(x)
        paste0("italic('", x, "')")) +
      labs(title    = "Top 10 SIMPER species",
           subtitle = "Contribution to between-habitat dissimilarity (%)",
           x = NULL, y = "Average contribution (%)") +
      theme_ecor() +
      theme(axis.text.y = element_text(face = "italic"))

    save_ecor_fig(fig4, "fig4_simper_final", width = 14, height = 10)
    cat("✓ Figure 4 saved.\n")
  }
}

# ── Composite figure (main manuscript) ────────────────────────────────────────

cat("\n--- Assembling composite figure ---\n")

figs_available <- list()
if (exists("fig1")) figs_available[["fig1"]] <- fig1
if (exists("fig2")) figs_available[["fig2"]] <- fig2
if (exists("fig3")) figs_available[["fig3"]] <- fig3
if (exists("fig4")) figs_available[["fig4"]] <- fig4

if (length(figs_available) == 4) {
  composite <- (figs_available$fig1 | figs_available$fig2) /
               (figs_available$fig3 | figs_available$fig4) +
    plot_annotation(
      tag_levels = "A",
      theme      = theme(plot.tag = element_text(face = "bold", size = 14))
    )

  save_ecor_fig(composite, "MAIN_composite_figure",
                width = 180, height = 130, units_mm = TRUE)
  cat("✓ Main composite figure saved (180×130mm, 300 DPI).\n")
  cat("  → outputs/figures/MAIN_composite_figure.png\n")
} else {
  cat("Composite figure skipped: the included example dataset is too small for every advanced figure.\n")
}

cat("\n✓ Visualization complete. All figures in outputs/figures/\n")

