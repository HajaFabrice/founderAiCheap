# ==============================================================================
# EcoR Conservation Project Template - 0_setup.R
# Project initialization + package installation
# Author: Haja Fabrice RAZAFINDRABE MAMINIAINA
# Version: 3.0 - v3 Pro bundle
# ==============================================================================
# Run this FIRST, on a fresh install of the project.
# Typical core-only runtime: 1-2 minutes.
# Full install with advanced spatial/SDM packages: 5-15 minutes and may
# require system libraries (GDAL, GEOS, PROJ) that R cannot install for you.
# ==============================================================================

cat("\n=== EcoR Conservation Project Template - Setup v3.0 ===\n")

# ── Installation profile ──────────────────────────────────────────────────────
# Default: install only the CORE packages needed by scripts 1, 2, 4, and 7.
# Set ECOR_INSTALL_ADVANCED to TRUE before sourcing this file if you also want
# the heavy spatial / SDM / genetics packages used by scripts 3, 5, and 6.
#
#   ECOR_INSTALL_ADVANCED <- TRUE
#   source("0_setup.R")
#
# You can also install advanced groups one at a time later, with for example:
#   install.packages(c("sf", "terra", "ggspatial"))    # spatial
#   install.packages(c("biomod2", "dismo", "ENMeval")) # SDM
#   install.packages(c("adegenet", "pegas", "ape"))    # genetics

if (!exists("ECOR_INSTALL_ADVANCED")) {
  ECOR_INSTALL_ADVANCED <- FALSE
}

cat(sprintf("Advanced packages requested: %s\n",
            ifelse(isTRUE(ECOR_INSTALL_ADVANCED), "yes", "no (core only)")))

# ── Core packages (always installed) ──────────────────────────────────────────

core_pkgs <- c(
  "here",          # Robust file paths
  "readr",         # Fast CSV import
  "readxl",        # Excel import
  "dplyr",         # Data manipulation
  "tidyr",         # Reshaping
  "tibble",        # Modern data frames
  "purrr",         # Functional helpers
  "janitor",       # Clean column names
  "skimr",         # Summary statistics
  "lubridate",     # Dates
  "glue",          # String interpolation
  "vegan",         # Diversity, NMDS, PERMANOVA
  "iNEXT",         # Rarefaction
  "ggplot2",       # Plotting
  "patchwork",     # Combine ggplots
  "scales",        # Axis formatting
  "RColorBrewer",  # Palettes
  "viridis",       # Colour-blind safe palettes
  "knitr",         # Tables, RMarkdown
  "broom",         # Tidy model outputs
  "tictoc"         # Step timing used by run_pipeline.R
)

# ── Advanced groups (only installed when ECOR_INSTALL_ADVANCED is TRUE) ───────
# These bring in system dependencies and large downloads. They are used by
# scripts 3 (spatial), 5 (SDM) and 6 (occupancy/genetics) and are intentionally
# optional so that scripts 1, 2, 4, and 7 can be tested first without them.

spatial_pkgs <- c("sf", "terra", "ggspatial")
sdm_pkgs     <- c("biomod2", "dismo", "ENMeval")
genetics_pkgs <- c("adegenet", "pegas", "ape", "hierfstat")
stats_pkgs   <- c("lme4", "lmerTest", "emmeans", "car", "MuMIn",
                  "unmarked", "betapart")
extra_viz    <- c("ggrepel", "ggpubr", "kableExtra", "rmarkdown", "quarto",
                  "tmap", "leaflet", "mapview", "geodata")

advanced_pkgs <- if (isTRUE(ECOR_INSTALL_ADVANCED)) {
  c(spatial_pkgs, sdm_pkgs, genetics_pkgs, stats_pkgs, extra_viz)
} else {
  character(0)
}

# ── Install missing packages ──────────────────────────────────────────────────

install_if_missing <- function(pkgs) {
  if (length(pkgs) == 0) return(invisible())
  missing <- pkgs[!(pkgs %in% installed.packages()[, "Package"])]
  if (length(missing) == 0) {
    cat("  All requested packages already installed.\n")
    return(invisible())
  }
  cat("  Installing:", paste(missing, collapse = ", "), "\n")
  install.packages(missing, repos = "https://cloud.r-project.org")
}

cat("\nCore packages...\n")
install_if_missing(core_pkgs)

if (length(advanced_pkgs) > 0) {
  cat("\nAdvanced packages (may require system libraries)...\n")
  install_if_missing(advanced_pkgs)
} else {
  cat("\nSkipping advanced spatial/SDM/genetics packages.\n")
  cat("To install them later, set ECOR_INSTALL_ADVANCED <- TRUE and re-source this file,\n")
  cat("or install groups individually as listed at the top of 0_setup.R.\n")
}

# ── Load core packages silently ───────────────────────────────────────────────

suppressPackageStartupMessages({
  for (pkg in c("here", "readr", "dplyr", "tidyr", "tibble",
                "janitor", "vegan", "ggplot2", "patchwork", "knitr")) {
    if (requireNamespace(pkg, quietly = TRUE)) {
      library(pkg, character.only = TRUE)
    }
  }
})

# ── Project directory structure ───────────────────────────────────────────────

dirs <- c(
  "data/raw",
  "data/processed",
  "outputs/figures",
  "outputs/tables",
  "outputs/models",
  "reports",
  "docs",
  "notebooks",
  "prompts",
  "functions"
)

invisible(lapply(dirs, function(d) {
  dir.create(here::here(d), recursive = TRUE, showWarnings = FALSE)
}))

cat("\nProject directories ready under: ", here::here(), "\n", sep = "")

# ── Anchor here() to project root ─────────────────────────────────────────────

here::i_am("0_setup.R")

# ── Global ggplot2 theme (EcoR publication style) ─────────────────────────────

theme_ecor <- function(base_size = 12) {
  ggplot2::theme_minimal(base_size = base_size) +
    ggplot2::theme(
      plot.title       = ggplot2::element_text(face = "bold", size = base_size + 1),
      plot.subtitle    = ggplot2::element_text(color = "grey50", size = base_size - 1),
      plot.caption     = ggplot2::element_text(color = "grey60", size = base_size - 2,
                                               hjust = 0),
      axis.text        = ggplot2::element_text(size = base_size - 1),
      legend.title     = ggplot2::element_text(face = "bold", size = base_size - 1),
      panel.grid.minor = ggplot2::element_blank(),
      strip.text       = ggplot2::element_text(face = "bold")
    )
}

ggplot2::theme_set(theme_ecor())

# Colour-blind friendly palette (Wong 2011, Nature Methods)
ECOR_PALETTE <- c(
  "#0F6E56", "#1D9E75", "#56B4E9", "#E69F00",
  "#D55E00", "#CC79A7", "#009E73", "#F0E442"
)

# Global seed for reproducibility
set.seed(42)

# ── Summary ───────────────────────────────────────────────────────────────────

cat("\nSetup complete.\n")
cat("Next steps:\n")
cat("  1. Run:  source('1_data_import_clean.R')\n")
cat("           (defaults to the included transect template in data/raw/)\n")
cat("  2. For the core community-ecology workflow, continue with:\n")
cat("       source('2_exploratory_analysis.R')\n")
cat("       source('4_biodiversity_metrics.R')\n")
cat("       source('7_visualization_publication.R')\n")
cat("  3. Advanced scripts 3 (spatial), 5 (SDM), and 6 (population/occupancy)\n")
cat("     require ECOR_INSTALL_ADVANCED <- TRUE and system libraries.\n")
cat("  4. Optional reproducibility: see RENV_README.md.\n\n")

cat("R version :", R.version$major, ".", R.version$minor, "\n")
if (requireNamespace("vegan", quietly = TRUE))   cat("vegan   :", as.character(packageVersion("vegan")), "\n")
if (requireNamespace("ggplot2", quietly = TRUE)) cat("ggplot2 :", as.character(packageVersion("ggplot2")), "\n")
