# EcoR Conservation Project Template

Version: 3.0 - v3 Pro technical workspace

This Pro bonus is a full RStudio project skeleton for conservation biology and
biodiversity monitoring. It includes core community-ecology scripts that run
out of the box on the bundled CSV template, plus advanced spatial, species
distribution modelling, and population/occupancy starter scripts that you can
opt in to once your machine is configured for them.

## Start Here

1. Open `EcoR_Conservation_Project_Template.Rproj` in RStudio.
2. Run `source("0_setup.R")` to install the core packages and create the
   project folder structure. The script does NOT install heavy spatial or SDM
   packages by default.
3. Run `source("1_data_import_clean.R")` to test the workflow on the bundled
   transect template (`data/raw/TEMPLATE_transect_survey.csv`).
4. Source `run_pipeline.R` and call `run_core()` for the safe community-ecology
   workflow (scripts 0, 1, 2, 4, 7).
5. Open the relevant notebook in `notebooks/` for an annotated, research-context
   example.

## Core vs Advanced

| Tier | Scripts | Packages |
|---|---|---|
| Core - tested by default | 1, 2, 4, 7 | tidyverse, vegan, iNEXT, ggplot2 |
| Advanced - opt in | 3, 5, 6 | sf, terra, biomod2, dismo, unmarked, geodata, ... |

To install the advanced packages, set `ECOR_INSTALL_ADVANCED <- TRUE` before
running `0_setup.R`. Spatial and SDM packages depend on system libraries (GDAL,
GEOS, PROJ) and CHELSA climate downloads. Treat them as advanced workflows that
may not run unattended on every machine.

## Included Notebooks

| Data context | Notebook |
|---|---|
| Transects / community ecology | `notebooks/Module1_Analyse_Transects_Herp_Madagascar.Rmd` |
| Behavioural focal follows | `notebooks/Module2_Behavioural_Ecology_Zonosaurus.Rmd` |
| Thermal tolerance / ecophysiology | `notebooks/Module3_Ecophysiology_Amphibians.Rmd` |
| Population genetics | `notebooks/Module4_Population_Genetics.Rmd` |
| Functional morphology | `notebooks/Module5_Functional_Morphology.Rmd` |

## Main Project Files

| File | Purpose |
|---|---|
| `0_setup.R` | Installs core packages, creates folders, optional advanced install |
| `1_data_import_clean.R` | Imports and cleans the bundled CSV template by default |
| `2_exploratory_analysis.R` | Exploratory summaries and diagnostic plots |
| `3_spatial_analysis.R` | Advanced: GIS, habitat mapping, protected-area context |
| `4_biodiversity_metrics.R` | Diversity indices, rarefaction, community summaries |
| `5_species_distribution.R` | Advanced: SDM starter with climate-data guidance |
| `6_population_dynamics.R` | Advanced: occupancy/population summaries, camera traps |
| `7_visualization_publication.R` | Publication-style figures and exports |
| `8_reporting.qmd` | Quarto report starter |
| `run_pipeline.R` | Sequential runner (`run_core()` / `run_advanced()`) |
| `_targets.R` | Optional reproducible pipeline skeleton (core workflow only) |
| `activate_renv.R` | Optional renv activation helper - no bundled lockfile |

## Prompts and Decision Help

- `prompts/50_Prompts_Biodiversity_R.md`
- `prompts/Prompt_Chaining_System.html`
- `docs/Statistical_Methods_Reference.md`
- `docs/Ethogram_Zonosaurus_karsteni.md`

## Reproducibility Note

This project ships reproducibility guidance, but NOT a machine-specific
`renv.lock`. Use `RENV_README.md` if you want to create your own lockfile after
confirming the package set works on your computer. Spatial and SDM packages in
particular are sensitive to operating system and R version, and a foreign
lockfile is more likely to fail than to help.

## Support Boundary

The bundled transect template and the core community-ecology workflow are the
safest first test. The advanced scripts (3, 5, 6) require internet access and
system dependencies that R alone cannot guarantee. Always check that the
statistical method matches your sampling design before using results in a
thesis, report, or manuscript.
