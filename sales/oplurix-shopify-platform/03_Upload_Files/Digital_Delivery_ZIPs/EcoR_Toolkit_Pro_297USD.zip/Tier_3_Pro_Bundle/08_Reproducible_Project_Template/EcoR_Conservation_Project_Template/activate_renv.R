# EcoR Conservation Project Template - optional renv helper.
#
# This v3 Pro bundle does NOT ship a `renv.lock` because spatial/SDM packages
# depend on operating system, R version, and system libraries. A lockfile
# generated on another machine often fails to restore for buyers.
#
# To turn this project into a fully version-locked workspace ON YOUR MACHINE:
#   1. Open the .Rproj file in RStudio.
#   2. Run 0_setup.R and confirm the core scripts work.
#   3. install.packages("renv")
#   4. renv::init()
#   5. renv::snapshot()
#
# After that, on another computer you can run:
#   renv::restore()
#
# This script only activates renv if a project-local renv folder already
# exists. It will never download a lockfile from somewhere else.

if (file.exists("renv/activate.R")) {
  source("renv/activate.R")
  message("renv project library activated.")
} else {
  message("No renv/ folder present. See RENV_README.md for setup steps.")
}
