# ==============================================================================
# EcoR Toolkit — 2_exploratory_analysis.R
# Quick EDA before committing to main analyses
# Run AFTER 1_data_import_clean.R
# ==============================================================================

library(here); library(dplyr); library(ggplot2)
library(skimr); library(patchwork); library(scales)

source(here("functions/utils_data.R"))
source(here("functions/utils_figures.R"))

cat("=== 2. EXPLORATORY ANALYSIS ===\n\n")

data        <- readRDS(here("data/processed/data_clean.rds"))
comm_matrix <- readRDS(here("data/processed/comm_matrix.rds"))

# ── 2.1 Full dataset skim ──────────────────────────────────────────────────────

cat("--- 2.1 Dataset overview ---\n")
print(skim(data))

# ── 2.2 Species accumulation by site ──────────────────────────────────────────

cat("\n--- 2.2 Species × site crosstab ---\n")

# Detect column names defensively
sp_col   <- detect_col(data, c("espece","species","sp"))
site_col <- detect_col(data, c("site","localite","location"))
cnt_col  <- detect_col(data, c("n_ind","count","abondance","n"))

crosstab <- data %>%
  filter(.data[[cnt_col]] > 0) %>%
  group_by(.data[[site_col]], .data[[sp_col]]) %>%
  summarise(n = sum(.data[[cnt_col]]), .groups = "drop") %>%
  tidyr::pivot_wider(names_from = sp_col, values_from = n,
                     values_fill = 0)

print(as.data.frame(crosstab))

# ── 2.3 Richness & abundance summary ──────────────────────────────────────────

cat("\n--- 2.3 Richness & abundance per site ---\n")

site_summary <- data %>%
  filter(.data[[cnt_col]] > 0) %>%
  group_by(.data[[site_col]]) %>%
  summarise(
    S          = n_distinct(.data[[sp_col]]),
    N          = sum(.data[[cnt_col]]),
    n_transect = n_distinct(if("transect_id" %in% names(.)) transect_id else site),
    .groups    = "drop"
  ) %>%
  mutate(density_100m = round(N / (n_transect * 200) * 100, 2))

print(site_summary)

# ── 2.4 Distribution checks ────────────────────────────────────────────────────

cat("\n--- 2.4 Normality tests ---\n")

# Shannon diversity (for later tests). Shapiro-Wilk requires 3-5000 values.
H_vals <- vegan::diversity(comm_matrix, index = "shannon")
if (length(H_vals) >= 3 && length(H_vals) <= 5000) {
  sw <- shapiro.test(H_vals)
  cat(sprintf("Shannon H' — Shapiro-Wilk: W = %.4f, p = %.4f → %s\n",
              sw$statistic, sw$p.value,
              ifelse(sw$p.value > 0.05,
                     "NORMAL → ANOVA applicable",
                     "NON-NORMAL → Kruskal-Wallis recommended")))
} else {
  cat(sprintf("Shannon H' — Shapiro-Wilk skipped: needs 3-5000 sites, found %d.\n",
              length(H_vals)))
}

# Raw abundance
if (nrow(data) <= 5000) {
  sw_n <- shapiro.test(data[[cnt_col]])
  cat(sprintf("Abundance N  — Shapiro-Wilk: W = %.4f, p = %.4f → %s\n",
              sw_n$statistic, sw_n$p.value,
              ifelse(sw_n$p.value > 0.05, "NORMAL", "NON-NORMAL → log+1 or Poisson GLM")))
}

# ── 2.5 EDA Figures ────────────────────────────────────────────────────────────

cat("\n--- 2.5 Generating EDA figures ---\n")

# Fig A: Abundance distribution
p_hist <- data %>%
  filter(.data[[cnt_col]] > 0) %>%
  ggplot(aes(x = .data[[cnt_col]])) +
  geom_histogram(fill = ECOR_PALETTE[1], color = "white",
                 binwidth = 1, alpha = 0.85) +
  scale_x_continuous(breaks = pretty_breaks()) +
  labs(title = "A — Abundance distribution",
       x = "Individuals per record", y = "Frequency") +
  theme_ecor()

# Fig B: Species per site
p_rich <- site_summary %>%
  ggplot(aes(x = reorder(.data[[site_col]], S), y = S,
             fill = .data[[site_col]])) +
  geom_col(width = 0.7) +
  geom_text(aes(label = S), hjust = -0.3, fontface = "bold", size = 3.5) +
  coord_flip() +
  scale_fill_manual(values = ECOR_PALETTE, guide = "none") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.15))) +
  labs(title = "B — Species richness per site",
       x = NULL, y = "Species richness (S)") +
  theme_ecor()

# Fig C: Abundance per site (log scale)
p_abund <- site_summary %>%
  ggplot(aes(x = reorder(.data[[site_col]], N), y = N,
             fill = .data[[site_col]])) +
  geom_col(width = 0.7) +
  coord_flip() +
  scale_fill_manual(values = ECOR_PALETTE, guide = "none") +
  scale_y_log10(labels = label_comma()) +
  labs(title = "C — Total abundance (log scale)",
       x = NULL, y = "Total individuals (log10)") +
  theme_ecor()

# Fig D: Rank-abundance (Whittaker plot)
rank_abund <- data %>%
  filter(.data[[cnt_col]] > 0) %>%
  group_by(.data[[sp_col]]) %>%
  summarise(total = sum(.data[[cnt_col]]), .groups = "drop") %>%
  arrange(desc(total)) %>%
  mutate(rank = row_number(),
         rel_abund = total / sum(total))

p_rank <- rank_abund %>%
  ggplot(aes(x = rank, y = rel_abund)) +
  geom_line(color = ECOR_PALETTE[1], linewidth = 1.2) +
  geom_point(color = ECOR_PALETTE[1], size = 2.5, alpha = 0.8) +
  scale_y_log10(labels = label_percent()) +
  labs(title = "D — Rank-abundance (Whittaker)",
       x = "Species rank", y = "Relative abundance (%)") +
  theme_ecor()

# Assemble
eda_fig <- (p_hist | p_rich) / (p_abund | p_rank) +
  plot_annotation(
    title    = "Exploratory Data Analysis",
    subtitle = "EcoR Toolkit · Run 2_exploratory_analysis.R",
    tag_levels = "A"
  )

save_ecor_fig(eda_fig, "eda_overview", width = 18, height = 13)
cat("✓ EDA figure saved to outputs/figures/eda_overview.png\n")

# ── 2.6 Save EDA outputs ──────────────────────────────────────────────────────

saveRDS(site_summary, here("data/processed/site_summary.rds"))
write.csv(site_summary, here("outputs/tables/site_summary.csv"),
          row.names = FALSE)

cat("\n✓ EDA complete. Outputs in outputs/figures/ and outputs/tables/\n")
cat("  → Proceed to 3_spatial_analysis.R or open a notebook.\n")

