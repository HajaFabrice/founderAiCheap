# ==============================================================================
# EcoR Toolkit — 5_species_distribution.R
# Species Distribution Modelling (SDM)
# Methods: biomod2 ensemble · CHELSA climate · future projections
# ==============================================================================
# WHAT YOU NEED:
#   data/raw/occurrences.csv   — species, lat, lon columns
#   Internet connection         — for CHELSA climate data download
# ==============================================================================

library(here); library(dplyr); library(sf); library(terra)
library(ggplot2); library(geodata)

source(here("functions/utils_spatial.R"))
source(here("functions/utils_figures.R"))

cat("=== 5. SPECIES DISTRIBUTION MODELLING ===\n\n")

# ── 5.1 Occurrence data ────────────────────────────────────────────────────────

cat("--- 5.1 Occurrence records ---\n")

occ_path <- here("data/raw/occurrences.csv")

if (!file.exists(occ_path)) {
  cat("⚠ No occurrences.csv found. Using demo data (Zonosaurus karsteni).\n\n")

  set.seed(42)
  occurrences <- data.frame(
    species = "Zonosaurus karsteni",
    lon     = c(44.652, 44.661, 44.668, 44.595, 44.720, 44.580,
                44.700, 44.640, 44.710, 44.630),
    lat     = c(-20.081, -20.095, -20.102, -20.050, -20.120, -20.035,
                -20.145, -20.060, -20.130, -20.090)
  )
  cat("Demo occurrences: Zonosaurus karsteni (Kirindy Forest)\n")
} else {
  occurrences <- read.csv(occ_path)
  cat("Loaded:", nrow(occurrences), "occurrence records\n")
}

# Remove duplicates and NA
occurrences <- occurrences %>%
  filter(!is.na(lon), !is.na(lat)) %>%
  distinct(lon, lat, .keep_all = TRUE)

cat("Clean records:", nrow(occurrences), "occurrences\n")
cat("Species:", unique(occurrences$species), "\n")

# ── 5.2 Download climate variables (CHELSA) ────────────────────────────────────

cat("\n--- 5.2 Climate variables (CHELSA 1km) ---\n")

chelsa_dir <- here("data/raw/chelsa")
dir.create(chelsa_dir, showWarnings = FALSE)

# Core bioclimatic variables for herpetofauna
# BIO1 = Annual mean temp | BIO12 = Annual precip
# BIO2 = Temp range       | BIO15 = Precip seasonality
CHELSA_VARS <- c(1, 2, 12, 15)

cat("Downloading CHELSA variables:", paste("BIO", CHELSA_VARS, collapse = ", "), "\n")

climate_stack <- tryCatch({
  geodata::worldclim_global(
    var  = "bio",
    res  = 2.5,    # 2.5 arcmin ≈ 5km (use 0.5 for 1km if needed)
    path = chelsa_dir
  )[[CHELSA_VARS]]
}, error = function(e) {
  cat("⚠ Climate download failed:", conditionMessage(e), "\n")
  cat("  Manual download: https://chelsa-climate.org/bioclim/\n")
  NULL
})

if (!is.null(climate_stack)) {
  # Crop to study area extent (+ 2° buffer)
  occ_vect  <- terra::vect(occurrences, geom = c("lon","lat"), crs = "EPSG:4326")
  ext_study <- terra::ext(occ_vect) + 2   # 2° buffer
  climate_stack <- terra::crop(climate_stack, ext_study)
  cat("✓ Climate stack:", nlyr(climate_stack), "variables\n")

  # Check for multicollinearity
  cat("\nCorrelation check (variables > 0.7 should be dropped):\n")
  clim_vals <- terra::spatSample(climate_stack, 1000, na.rm = TRUE)
  cor_mat   <- round(cor(clim_vals, use = "complete.obs"), 2)
  high_cor  <- which(abs(cor_mat) > 0.7 & cor_mat != 1, arr.ind = TRUE)
  if (nrow(high_cor) > 0) {
    cat("High correlations:\n")
    print(cor_mat[unique(high_cor[,1]), unique(high_cor[,2])])
    cat("→ Consider removing correlated variables.\n")
  } else {
    cat("✓ No high multicollinearity detected.\n")
  }
}

# ── 5.3 Background points ─────────────────────────────────────────────────────

cat("\n--- 5.3 Background / pseudo-absence points ---\n")

if (!is.null(climate_stack)) {
  # Sample background from a 200km radius (spatial thinning approach)
  set.seed(42)
  bg_points <- terra::spatSample(
    climate_stack[[1]],
    size   = 10000,
    method = "random",
    na.rm  = TRUE,
    as.points = TRUE
  )
  bg_df <- as.data.frame(bg_points, geom = "XY") %>%
    rename(lon = x, lat = y) %>%
    select(lon, lat) %>%
    mutate(presence = 0)

  occ_df <- occurrences %>%
    select(lon, lat) %>%
    mutate(presence = 1)

  sdm_data <- bind_rows(occ_df, bg_df %>% slice_sample(n = 1000))
  cat("SDM dataset:", sum(sdm_data$presence), "presences +",
      sum(1 - sdm_data$presence), "background points\n")
}

# ── 5.4 Maxent / GLM SDM ─────────────────────────────────────────────────────

cat("\n--- 5.4 Species distribution model ---\n")

if (!is.null(climate_stack)) {

  # Extract climate at occurrence + background points
  all_pts  <- terra::vect(sdm_data, geom = c("lon","lat"), crs = "EPSG:4326")
  clim_pts <- terra::extract(climate_stack, all_pts, ID = FALSE)
  sdm_df   <- bind_cols(sdm_data, clim_pts) %>% na.omit()

  # GLM as a baseline SDM (no MaxEnt dependency)
  var_names <- names(climate_stack)
  formula_sdm <- as.formula(paste(
    "presence ~", paste(var_names, collapse = " + ")
  ))

  sdm_glm <- glm(formula_sdm, data = sdm_df,
                 family = binomial(link = "logit"))

  cat("GLM SDM summary:\n")
  print(summary(sdm_glm)$coefficients)

  # Model performance (AUC)
  if (requireNamespace("pROC", quietly = TRUE)) {
    pred_train <- predict(sdm_glm, type = "response")
    auc_val    <- pROC::auc(sdm_df$presence, pred_train)
    cat(sprintf("\nModel AUC: %.3f (%s)\n", auc_val,
                ifelse(auc_val > 0.9, "Excellent",
                ifelse(auc_val > 0.7, "Good",
                                      "Poor — check model"))))
  }

  # ── 5.5 Predict to raster ─────────────────────────────────────────────────

  cat("\n--- 5.5 Prediction map ---\n")

  pred_raster <- terra::predict(
    climate_stack, sdm_glm,
    type  = "response",
    na.rm = TRUE
  )

  terra::writeRaster(pred_raster,
                     here("outputs/figures/sdm_habitat_suitability.tif"),
                     overwrite = TRUE)

  # Convert to ggplot-friendly dataframe
  pred_df <- as.data.frame(pred_raster, xy = TRUE, na.rm = TRUE)
  names(pred_df)[3] <- "suitability"

  occ_pts <- occurrences %>% select(lon, lat)

  map_sdm <- ggplot() +
    geom_raster(data = pred_df,
                aes(x = x, y = y, fill = suitability)) +
    geom_point(data = occ_pts, aes(x = lon, y = lat),
               color = "white", shape = 3, size = 2, stroke = 1.2) +
    scale_fill_gradientn(
      colors = c("#F5F5F5","#A8D5C2","#1D9E75","#0F6E56"),
      name   = "Habitat\nsuitability",
      limits = c(0, 1)
    ) +
    ggspatial::annotation_scale(location = "bl") +
    ggspatial::annotation_north_arrow(location = "tl") +
    labs(
      title    = paste0("Predicted habitat suitability — ",
                         unique(occurrences$species)[1]),
      subtitle = "GLM · CHELSA bioclimatic variables",
      x = "Longitude", y = "Latitude",
      caption  = "Cross = occurrence records"
    ) +
    theme_ecor()

  save_ecor_fig(map_sdm, "sdm_habitat_suitability", width = 14, height = 12)
  cat("✓ SDM prediction map saved.\n")

  # ── 5.6 Future projections ─────────────────────────────────────────────────

  cat("\n--- 5.6 Climate change projections ---\n")
  cat("For future projections (RCP/SSP scenarios):\n")
  cat("  1. Download CHELSA future layers: https://chelsa-climate.org/cmip6/\n")
  cat("  2. Crop to study extent (same as above)\n")
  cat("  3. Re-run terra::predict(future_stack, sdm_glm)\n")
  cat("  See Module 3 (Ecophysiology) for climate vulnerability framework.\n")

} else {
  cat("⚠ Skipping SDM — climate data not available.\n")
  cat("  Ensure internet connection and rerun.\n")
}

# ── 5.7 biomod2 ensemble (advanced) ───────────────────────────────────────────

cat("\n--- 5.7 Ensemble SDM with biomod2 (advanced) ---\n")
cat("biomod2 runs multiple algorithms (GLM, GAM, BRT, RF, MaxEnt)\n")
cat("and combines them into a weighted ensemble.\n\n")

cat("Quick start:\n")
cat('
library(biomod2)

# Format data
bm_data <- BIOMOD_FormatingData(
  resp.var      = occurrences$presence,
  expl.var      = climate_stack,
  resp.coord    = occurrences[, c("lon","lat")],
  resp.name     = "Zonosaurus_karsteni",
  PA.nb.rep     = 3,
  PA.nb.absences = 1000
)

# Run models
bm_models <- BIOMOD_Modeling(
  bm.format  = bm_data,
  models     = c("GLM","GBM","RF","MAXNET"),
  nb.rep     = 3,
  data.split.perc = 80
)

# Ensemble
bm_ensemble <- BIOMOD_EnsembleModeling(
  bm.mod     = bm_models,
  models.chosen = "all",
  em.by      = "all",
  metric.select = "TSS",
  metric.select.thresh = 0.7
)

# Predict
bm_proj <- BIOMOD_Projection(...)
bm_ef   <- BIOMD_EnsembleForecasting(...)
')

cat("→ Full biomod2 tutorial: notebooks/Module1_Analyse_Transects_Herp_Madagascar.Rmd\n")

cat("\n✓ Species distribution modelling complete.\n")

