# Changelog

## 1.1.0 - 2026-05-15

Safety and consistency pass for the v3 Pro bundle.

Changed:

- `0_setup.R` only installs core community-ecology packages by default. Heavy
  spatial / SDM / genetics packages are opt-in via `ECOR_INSTALL_ADVANCED`.
- `run_pipeline.R` no longer auto-runs. It exposes `run_core()`, `run_advanced()`,
  and `run(c(...))` so buyers can choose which scripts to execute.
- `_targets.R` now defines a CORE-only targets graph (no `sf`, `terra`,
  `geodata` in `tar_option_set`). Spatial steps are intentionally not wired in
  by default.
- `activate_renv.R` no longer calls `renv::restore()` against a missing
  lockfile. It only activates an existing project-local renv folder.
- README, USER_GUIDE, and RENV_README updated to clearly label scripts 3, 5,
  and 6 as advanced and dependency-heavy.

## 1.0.0 - 2026-05-11

Initial premium product release.

Added:

- Reproducible R project structure
- Setup, cleaning, EDA, spatial, biodiversity, SDM, population, visualization,
  and reporting scripts
- Helper functions for data, spatial, diversity, modeling, and figures
- Bundled CSV templates under `data/raw/`
- Quarto report template
- `targets` automation pipeline
- Beginner-friendly `run_pipeline.R`
- `renv` documentation
- User guide, citation file, license, and sales assets
