# ==============================================================================
# EcoR Toolkit — functions/utils_spatial.R
# GIS helpers: coordinate validation, distance, raster extraction
# ==============================================================================

library(sf)
library(terra)

# ── Validate coordinates ───────────────────────────────────────────────────────
validate_coords <- function(df, lat_col = "lat", lon_col = "lon") {
  issues <- c()
  if (any(abs(df[[lat_col]]) > 90,  na.rm = TRUE)) issues <- c(issues, "lat out of range")
  if (any(abs(df[[lon_col]]) > 180, na.rm = TRUE)) issues <- c(issues, "lon out of range")
  if (any(is.na(df[[lat_col]]))  || any(is.na(df[[lon_col]])))
    issues <- c(issues, "NA coordinates")
  if (length(issues) > 0)
    warning("Coordinate issues: ", paste(issues, collapse = "; "))
  else
    message("✓ All coordinates valid.")
  invisible(df)
}

# ── Haversine distance (km) ────────────────────────────────────────────────────
haversine_km <- function(lat1, lon1, lat2, lon2) {
  R    <- 6371
  dlat <- (lat2 - lat1) * pi / 180
  dlon <- (lon2 - lon1) * pi / 180
  a    <- sin(dlat/2)^2 +
          cos(lat1 * pi/180) * cos(lat2 * pi/180) * sin(dlon/2)^2
  R * 2 * atan2(sqrt(a), sqrt(1 - a))
}

# ── Build site distance matrix ────────────────────────────────────────────────
site_distance_matrix <- function(sites_df,
                                  lat_col = "lat", lon_col = "lon",
                                  site_col = "site") {
  n    <- nrow(sites_df)
  mat  <- matrix(0, n, n,
                  dimnames = list(sites_df[[site_col]], sites_df[[site_col]]))
  for (i in seq_len(n)) {
    for (j in seq_len(n)) {
      if (i != j) {
        mat[i, j] <- haversine_km(
          sites_df[[lat_col]][i], sites_df[[lon_col]][i],
          sites_df[[lat_col]][j], sites_df[[lon_col]][j]
        )
      }
    }
  }
  as.dist(mat)
}

# ── Extract raster values at points ──────────────────────────────────────────
extract_raster_at_points <- function(raster_obj, points_df,
                                      lat_col = "lat", lon_col = "lon",
                                      crs_epsg = 4326) {
  pts  <- terra::vect(points_df, geom = c(lon_col, lat_col),
                      crs = paste0("EPSG:", crs_epsg))
  vals <- terra::extract(raster_obj, pts, ID = FALSE)
  cbind(points_df, vals)
}

# ── Create study area bounding box ────────────────────────────────────────────
study_extent <- function(sites_sf, buffer_km = 10) {
  buf_m <- buffer_km * 1000
  sites_proj <- sf::st_transform(sites_sf, 3857)   # metres
  bbox        <- sf::st_buffer(sf::st_union(sites_proj), buf_m)
  sf::st_transform(bbox, 4326)
}

# ── Reproject safely ──────────────────────────────────────────────────────────
safe_reproject <- function(layer, target_crs = 4326) {
  if (inherits(layer, "SpatRaster")) {
    if (terra::crs(layer) != terra::crs(paste0("EPSG:", target_crs)))
      layer <- terra::project(layer, paste0("EPSG:", target_crs))
  } else if (inherits(layer, "sf")) {
    if (sf::st_crs(layer)$epsg != target_crs)
      layer <- sf::st_transform(layer, target_crs)
  }
  layer
}

