# ==============================================================================
# EcoR Toolkit — 3_spatial_analysis.R
# GIS, habitat mapping, protected area overlap, connectivity
# Integrates EcoR v3 spatial scaffold and field data context
# ==============================================================================
# DATA REQUIREMENTS:
#   data/raw/sites.csv        — columns: site, lat, lon (+ optional: habitat)
#   data/raw/protected_areas/ — WDPA shapefiles (download from protectedplanet.net)
#   data/raw/dem/             — SRTM elevation raster (auto-downloaded if missing)
# ==============================================================================

library(here); library(sf); library(terra); library(dplyr)
library(ggplot2); library(ggspatial); library(tmap)
library(geodata)  # CHELSA climate + SRTM auto-download

source(here("functions/utils_figures.R"))
source(here("functions/utils_spatial.R"))

cat("=== 3. SPATIAL ANALYSIS & GIS ===\n\n")

# ── 3.1 Load site coordinates ─────────────────────────────────────────────────

data <- readRDS(here("data/processed/data_clean.rds"))

# Detect coordinate columns
lat_col <- detect_col(data, c("lat","latitude","y","LAT"))
lon_col <- detect_col(data, c("lon","longitude","x","LON"))

if (is.null(lat_col) || is.null(lon_col)) {
  cat("⚠ No coordinate columns found in data.\n")
  cat("  → Add 'lat' and 'lon' columns to your raw data.\n")
  cat("  → Demo mode: using Kirindy Forest coordinates.\n\n")

  # Demo: Kirindy Forest, Madagascar
  sites_coords <- data.frame(
    site    = c("Foret_Primaire","Foret_Secondaire","Lisiere","Savane","Zone_Agricole"),
    lat     = c(-20.081, -20.095, -20.102, -20.115, -20.130),
    lon     = c( 44.652,  44.661,  44.668,  44.680,  44.695),
    habitat = c("Primary","Secondary","Edge","Savanna","Agricultural")
  )
} else {
  sites_coords <- data %>%
    group_by(across(any_of(c("site","localite","habitat")))) %>%
    summarise(
      lat = mean(.data[[lat_col]], na.rm = TRUE),
      lon = mean(.data[[lon_col]], na.rm = TRUE),
      .groups = "drop"
    )
}

# Convert to sf object (WGS84)
sites_sf <- st_as_sf(sites_coords, coords = c("lon","lat"), crs = 4326)
cat("✓ Site coordinates loaded:", nrow(sites_sf), "sites\n")

# ── 3.2 Download elevation (SRTM) ─────────────────────────────────────────────

cat("\n--- 3.2 Elevation data (SRTM 90m) ---\n")

dem_path <- here("data/raw/dem/srtm_madagascar.tif")

if (!file.exists(dem_path)) {
  cat("Downloading SRTM elevation for Madagascar...\n")
  tryCatch({
    dem <- geodata::elevation_3s(
      lon  = mean(sites_coords$lon),
      lat  = mean(sites_coords$lat),
      path = here("data/raw/dem")
    )
    cat("✓ Elevation downloaded.\n")
  }, error = function(e) {
    cat("⚠ Download failed (check internet connection).\n")
    cat("  Manual download: https://srtm.csi.cgiar.org/\n")
    dem <<- NULL
  })
} else {
  dem <- terra::rast(dem_path)
  cat("✓ Elevation loaded from cache.\n")
}

if (!is.null(dem)) {
  # Extract elevation at each site
  sites_sf$elevation_m <- terra::extract(
    dem,
    terra::vect(sites_sf)
  )[, 2]
  cat("Elevation at sites (m):\n")
  print(sites_sf[, c("site","elevation_m")])
}

# ── 3.3 Protected area overlap ────────────────────────────────────────────────

cat("\n--- 3.3 Protected area analysis ---\n")

wdpa_path <- here("data/raw/protected_areas")

if (!dir.exists(wdpa_path) || length(list.files(wdpa_path)) == 0) {
  cat("⚠ No WDPA shapefiles found in data/raw/protected_areas/\n")
  cat("  Download from: https://www.protectedplanet.net/en/thematic-areas/wdpa\n")
  cat("  Filter for Madagascar (ISO3: MDG) and save as shapefile.\n")

  # Demo: create a buffer zone around sites as proxy
  cat("  Demo mode: using 10km buffer around study area.\n")
  study_area <- st_buffer(st_union(sites_sf), 10000)
  pa_overlap  <- NULL
} else {
  # Load WDPA
  wdpa_files <- list.files(wdpa_path, pattern = "\\.shp$",
                            full.names = TRUE)
  protected  <- st_read(wdpa_files[1], quiet = TRUE)

  # Reproject to match sites
  if (st_crs(protected) != st_crs(sites_sf)) {
    protected <- st_transform(protected, st_crs(sites_sf))
  }

  # Find sites within protected areas
  pa_overlap <- st_join(sites_sf, protected, join = st_within)

  cat("Sites within protected areas:\n")
  print(pa_overlap[, c("site","NAME","IUCN_CAT","GIS_AREA")])
}

# ── 3.4 Distance matrix (site-to-site) ────────────────────────────────────────

cat("\n--- 3.4 Geographic distance matrix ---\n")

geo_dist <- st_distance(sites_sf)
rownames(geo_dist) <- colnames(geo_dist) <- sites_sf$site
cat("Geographic distances between sites (metres):\n")
print(round(geo_dist))

# Save for IBD analysis in Module 4
saveRDS(geo_dist, here("data/processed/geo_distance_matrix.rds"))

# ── 3.5 Habitat classification from raster ────────────────────────────────────

cat("\n--- 3.5 Habitat context ---\n")

# If you have a land cover raster, extract habitat class at each site
lc_path <- here("data/raw/landcover/landcover.tif")

if (file.exists(lc_path)) {
  lc_raster <- terra::rast(lc_path)
  sites_sf$habitat_class <- terra::extract(
    lc_raster, terra::vect(sites_sf)
  )[, 2]
  cat("✓ Habitat classes extracted from land cover raster.\n")
} else {
  cat("  No land cover raster found — using field-assigned habitats.\n")
  cat("  Download ESA WorldCover 10m: https://esa-worldcover.org/\n")
}

# ── 3.6 Maps ──────────────────────────────────────────────────────────────────

cat("\n--- 3.6 Generating study area maps ---\n")

# Map 1: Site locations
map_sites <- ggplot() +
  geom_sf(data = sites_sf,
          aes(color = if("habitat" %in% names(sites_sf)) habitat else "Site"),
          size = 4, alpha = 0.85) +
  ggspatial::annotation_scale(location = "bl") +
  ggspatial::annotation_north_arrow(location = "tl",
    style = ggspatial::north_arrow_fancy_orienteering()) +
  scale_color_manual(values = ECOR_PALETTE, name = "Habitat") +
  labs(
    title    = "Study site locations",
    subtitle = paste(nrow(sites_sf), "sites —", unique(sites_sf$site)[1],
                     "region, Madagascar"),
    caption  = "CRS: WGS84 (EPSG:4326)"
  ) +
  theme_ecor() +
  theme(axis.text = element_text(size = 7))

save_ecor_fig(map_sites, "map_study_sites", width = 14, height = 12)
cat("✓ Study area map saved.\n")

# ── 3.7 Save spatial outputs ──────────────────────────────────────────────────

st_write(sites_sf, here("data/processed/sites.gpkg"),
         delete_dsn = TRUE, quiet = TRUE)

saveRDS(sites_sf, here("data/processed/sites_sf.rds"))

cat("\n✓ Spatial analysis complete.\n")
cat("  → sites_sf.rds: sf object with coordinates + elevation\n")
cat("  → geo_distance_matrix.rds: for IBD analysis (Module 4)\n")
cat("  → Proceed to 4_biodiversity_metrics.R\n")

