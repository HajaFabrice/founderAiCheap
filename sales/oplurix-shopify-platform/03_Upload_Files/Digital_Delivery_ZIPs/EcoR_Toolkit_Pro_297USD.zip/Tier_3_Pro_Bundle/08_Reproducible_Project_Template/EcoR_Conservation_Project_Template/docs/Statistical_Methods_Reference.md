# Statistical Methods Reference
## EcoR Toolkit · Quick decision guide for field biologists

---

## The 3-question framework

Before choosing any test, answer:

1. **What is my variable type?**  
   Continuous index / Species count / Presence-absence / Community matrix

2. **Is my data normal?**  
   `shapiro.test(your_variable)` — if p > 0.05 → normal

3. **How many groups?**  
   2 groups / 3+ groups / Continuous predictor

---

## Decision table

| Variable | Normal | Groups | Test | Post-hoc | R function |
|----------|--------|--------|------|----------|------------|
| Diversity index | Yes | 2 indep. | t-test | — | `t.test()` |
| Diversity index | Yes | 2 paired | Paired t | — | `t.test(paired=T)` |
| Diversity index | Yes | 3+ | ANOVA | Tukey HSD | `aov()` + `TukeyHSD()` |
| Diversity index | Yes | Continuous | Linear regression | — | `lm()` |
| Diversity index | No | 2 indep. | Mann-Whitney | — | `wilcox.test()` |
| Diversity index | No | 2 paired | Wilcoxon signed | — | `wilcox.test(paired=T)` |
| Diversity index | No | 3+ | Kruskal-Wallis | Dunn+Bonferroni | `kruskal.test()` + `dunn.test()` |
| Diversity index | No | Continuous | Spearman | — | `cor.test(method="spearman")` |
| Community matrix | — | Visualise | NMDS | — | `vegan::metaMDS()` |
| Community matrix | — | Test groups | PERMANOVA | pairwise.adonis2 | `vegan::adonis2()` |
| Community matrix | — | Env. relation | RDA / CCA | — | `vegan::rda()` / `vegan::cca()` |
| Community matrix | — | Key species | SIMPER | — | `vegan::simper()` |
| Counts (abundance) | — | Model | Poisson GLM | — | `glm(family=poisson)` |
| Counts (abundance) | — | Overdispersed | Neg. binomial | — | `MASS::glm.nb()` |
| Presence/absence | — | Model | Logistic regression | — | `glm(family=binomial)` |
| Presence/absence | — | Imperfect detect. | Occupancy model | — | `unmarked::occu()` |

---

## Effect sizes (always report alongside p-values)

| Test | Effect size | R code | Interpretation |
|------|-------------|--------|----------------|
| t-test | Cohen's d | `effectsize::cohens_d()` | 0.2 small / 0.5 med / 0.8 large |
| ANOVA | eta² (η²) | `effectsize::eta_squared()` | 0.01 / 0.06 / 0.14 |
| Kruskal-Wallis | rank η² | `effectsize::rank_eta_squared()` | same thresholds |
| Mann-Whitney | r (rank-biserial) | `effectsize::rank_biserial()` | 0.1 / 0.3 / 0.5 |
| Wilcoxon signed | r | `effectsize::rank_biserial(paired=T)` | same |
| Correlation | r² | `cor^2` | % variance explained |
| PERMANOVA | R² | from `adonis2()` output | % composition variance |
| lmer | R² marg/cond | `MuMIn::r.squaredGLMM()` | fixed / fixed+random |

---

## Assumptions checklist (complete BEFORE analysis)

### For parametric tests (t-test, ANOVA, regression)
```r
# 1. Normality of residuals
model <- aov(H ~ habitat, data = df)
shapiro.test(residuals(model))  # p > 0.05 needed

# 2. Homoscedasticity
car::leveneTest(H ~ habitat, data = df)  # p > 0.05 needed

# 3. Independence
# → Verify study design. If same sites measured repeatedly → use lmer()
```

### For PERMANOVA
```r
# Homogeneity of dispersion MUST be tested first
bray <- vegan::vegdist(comm, "bray")
disp <- vegan::betadisper(bray, groups)
vegan::permutest(disp)  # p > 0.05 → dispersion OK → PERMANOVA valid
```

### For mixed models (lmer)
```r
# 1. Residuals ~ normal (check QQ-plot)
plot(model)  # 4-panel diagnostic

# 2. Random effects adequate
# At least 5 levels per random effect

# 3. Singular fit warning
# → Random effect variance = 0 → simplify model structure
```

---

## Common mistakes and corrections

| Mistake | Why it's wrong | Correct approach |
|---------|----------------|-----------------|
| Pearson on ranked variable | Assumes linearity + normality | Use Spearman |
| ANOVA without normality check | Violates core assumption | Check Shapiro first |
| PERMANOVA without betadisper | Can be significant due to dispersion not centroids | Run betadisper first |
| Report p-value without effect size | p depends on n — not biologically interpretable alone | Always add η², R², d |
| Raw richness comparison without rarefaction | More sampling = more species, regardless of true diversity | Use iNEXT or standardise effort |
| Pseudoreplication (same individual measured 3× as independent) | Inflates degrees of freedom | Use lmer with (1\|individual) |
| ANOSIM alone without NMDS | R statistic hard to interpret without visual | Always pair with ordination |
| stepAIC on non-candidate models | Data dredging / overfitting | Pre-define candidate models |

---

## Reporting standards (journal requirements)

### What to always include in text
- Test statistic (F, H, χ², r, R)
- Degrees of freedom
- p-value (three decimal places, or "< 0.001")
- Effect size with 95% CI
- Sample size per group

### Format examples
```
"Shannon diversity differed significantly among habitat types
(Kruskal-Wallis: H = 14.3, df = 4, p = 0.006, rank η² = 0.68,
95% CI [0.41, 0.85])."

"Community composition differed significantly among habitats
(PERMANOVA: F = 4.87, R² = 0.44, p = 0.001, 999 permutations;
betadisper: F = 1.43, p = 0.21)."

"Foraging time was negatively predicted by shrub density
(β = −2.38 ± 0.61 SE, t = −3.90, p < 0.001, n = 192 sessions)."
```

---

## Package versions used in EcoR Toolkit v2.0

| Package | Version | Purpose |
|---------|---------|---------|
| vegan | 2.6+ | Community ecology |
| iNEXT | 3.0+ | Rarefaction |
| lme4 | 1.1+ | Mixed models |
| lmerTest | 3.1+ | Mixed model p-values |
| effectsize | 0.8+ | Effect sizes |
| betapart | 1.6+ | Beta diversity |
| dunn.test | 1.3+ | Kruskal post-hoc |
| unmarked | 1.3+ | Occupancy models |

---

*EcoR Toolkit v2.0 · Statistical Methods Reference*  
*Haja Fabrice RAZAFINDRABE MAMINIAINA · hajafabrice.r@gmail.com*

