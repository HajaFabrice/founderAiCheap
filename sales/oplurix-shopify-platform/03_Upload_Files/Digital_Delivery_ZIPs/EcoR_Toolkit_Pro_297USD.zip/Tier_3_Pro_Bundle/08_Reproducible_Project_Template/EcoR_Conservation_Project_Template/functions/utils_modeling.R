# ==============================================================================
# EcoR Toolkit — functions/utils_modeling.R
# Mixed model helpers, AIC tables, effect sizes
# ==============================================================================

library(lme4); library(lmerTest)

# ── AIC comparison table ──────────────────────────────────────────────────────
aic_table <- function(..., model_names = NULL) {
  models <- list(...)
  if (is.null(model_names))
    model_names <- paste0("M", seq_along(models))

  aic_vals <- sapply(models, AIC)
  df_vals  <- sapply(models, function(m)
    tryCatch(attr(logLik(m), "df"), error = function(e) NA))

  tbl <- data.frame(
    Model   = model_names,
    df      = df_vals,
    AIC     = round(aic_vals, 2),
    dAIC    = round(aic_vals - min(aic_vals), 2),
    Weight  = round(
      exp(-0.5 * (aic_vals - min(aic_vals))) /
      sum(exp(-0.5 * (aic_vals - min(aic_vals)))), 3
    )
  ) %>% dplyr::arrange(AIC)

  cat("=== AIC MODEL COMPARISON ===\n")
  print(tbl)
  cat("\nBest model:", tbl$Model[1], "(dAIC = 0)\n")
  invisible(tbl)
}

# ── R² marginal + conditional (lme4) ─────────────────────────────────────────
r2_mixed <- function(model) {
  if (!requireNamespace("MuMIn", quietly = TRUE))
    stop("Package 'MuMIn' required.")
  r2 <- MuMIn::r.squaredGLMM(model)
  cat(sprintf(
    "R² marginal (fixed only) = %.3f\n",   r2[1, "R2m"]))
  cat(sprintf(
    "R² conditional (fixed + random) = %.3f\n", r2[1, "R2c"]))
  invisible(r2)
}

# ── Variance partition (lmer) ─────────────────────────────────────────────────
var_partition <- function(model) {
  vc    <- as.data.frame(lme4::VarCorr(model))
  total <- sum(vc$vcov)
  vc$pct <- round(vc$vcov / total * 100, 1)
  cat("=== VARIANCE COMPONENTS ===\n")
  print(vc[, c("grp","vcov","pct")])
  cat(sprintf(
    "ICC (intraclass) = %.3f\n",
    vc$vcov[vc$grp != "Residual"][1] / total
  ))
  invisible(vc)
}

# ── Effect size for Kruskal ───────────────────────────────────────────────────
kruskal_eta2 <- function(kw_result, n_total) {
  # Rank eta-squared (η²H) — Tomczak & Tomczak 2014
  H <- kw_result$statistic
  k <- kw_result$parameter + 1
  eta2 <- (H - k + 1) / (n_total - k)
  cat(sprintf("Rank η² = %.3f (%s effect)\n",
              eta2,
              ifelse(eta2 >= 0.14, "large",
              ifelse(eta2 >= 0.06, "medium", "small"))))
  invisible(eta2)
}

# ── Tidy lmer output table ────────────────────────────────────────────────────
tidy_lmer <- function(model) {
  if (!requireNamespace("broom.mixed", quietly = TRUE))
    stop("Package 'broom.mixed' required.")
  broom.mixed::tidy(model, effects = "fixed", conf.int = TRUE) %>%
    dplyr::mutate(
      sig = dplyr::case_when(
        p.value < 0.001 ~ "***",
        p.value < 0.01  ~ "**",
        p.value < 0.05  ~ "*",
        p.value < 0.10  ~ ".",
        TRUE            ~ "ns"
      )
    ) %>%
    dplyr::select(term, estimate, conf.low, conf.high,
                  statistic, p.value, sig)
}

