# Optional renv Guide

EcoR Conservation Project Template includes reproducibility guidance, but this
v3 Pro bundle does NOT ship a `renv.lock`. Spatial, SDM, and population
modelling packages depend on your operating system, R version, and system
libraries (GDAL, GEOS, PROJ, sometimes Java). A lockfile generated on one
machine often fails to restore on another, so we ask you to create your own
after a successful local setup.

## Recommended Workflow

1. Open `EcoR_Conservation_Project_Template.Rproj` in RStudio.
2. Confirm the core workflow runs on your machine:

```r
source("0_setup.R")
source("1_data_import_clean.R")
```

3. If you want to also test the advanced spatial / SDM / occupancy scripts:

```r
ECOR_INSTALL_ADVANCED <- TRUE
source("0_setup.R")
```

4. Once everything you need installs cleanly, initialise your own lockfile:

```r
install.packages("renv")
renv::init()
renv::snapshot()
```

5. On another computer, restore your own lockfile with:

```r
renv::restore()
```

## Why No Bundled Lockfile?

- Spatial packages (`sf`, `terra`, `tmap`) and SDM packages (`biomod2`,
  `dismo`, `ENMeval`) ship with version pins that change rapidly.
- System libraries are not part of the lockfile and vary between Windows,
  macOS, and Linux.
- A foreign lockfile that fails to restore is worse than no lockfile, because
  it blocks setup and confuses the buyer.

`activate_renv.R` is a thin helper that only activates an existing
project-local renv folder. It will NOT silently download or restore from a
foreign lockfile.
