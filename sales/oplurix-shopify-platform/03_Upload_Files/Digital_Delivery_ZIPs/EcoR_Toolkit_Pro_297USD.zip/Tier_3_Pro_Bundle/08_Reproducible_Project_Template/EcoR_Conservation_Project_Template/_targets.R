# ==============================================================================
# EcoR Conservation Project Template - _targets.R
# Optional reproducible pipeline skeleton using the {targets} package
# ==============================================================================
# This pipeline covers the CORE community-ecology workflow (import, clean,
# community matrix, alpha diversity, rarefaction, multivariate tests, figures).
#
# Spatial / SDM / occupancy steps from scripts 3, 5, and 6 are NOT wired into
# this targets graph because they require optional system libraries (sf,
# terra, biomod2, etc.). Add them manually after you have confirmed the
# packages install cleanly on your machine.
#
# USAGE:
#   install.packages(c("targets", "tarchetypes"))
#   library(targets)
#   tar_make()         # Run all outdated targets
#   tar_visnetwork()   # Visualise the dependency graph
#   tar_read(alpha_div)
# ==============================================================================

library(targets)
library(tarchetypes)

# Source utility functions used inside targets
tar_source("functions/utils_data.R")
tar_source("functions/utils_diversity.R")
tar_source("functions/utils_figures.R")

tar_option_set(
  packages = c(
    "dplyr", "tidyr", "readr", "readxl",
    "janitor", "tibble",
    "vegan", "iNEXT",
    "ggplot2", "patchwork",
    "knitr", "here"
  ),
  seed   = 42,
  format = "rds"
)

list(

  # ── 1. Track raw data file (re-runs everything if it changes) ──────────────

  tar_target(
    name    = raw_data_file,
    command = "data/raw/TEMPLATE_transect_survey.csv",
    format  = "file"
  ),

  # ── 2. Import and clean ────────────────────────────────────────────────────

  tar_target(
    name    = data_clean,
    command = {
      df <- safe_read(raw_data_file)
      df <- df %>%
        janitor::clean_names()
      if ("date" %in% names(df)) {
        df$date <- as.Date(as.character(df$date))
      }
      if ("site" %in% names(df))   df$site   <- as.factor(df$site)
      if ("espece" %in% names(df)) df$espece <- as.factor(df$espece)
      if ("n_ind" %in% names(df)) {
        df$n_ind <- as.integer(pmax(0, df$n_ind, na.rm = TRUE))
      }
      df
    }
  ),

  tar_target(
    name    = comm_matrix,
    command = build_comm_matrix(data_clean)
  ),

  tar_target(
    name    = site_summary,
    command = site_summary_table(data_clean)
  ),

  # ── 3. Alpha diversity ─────────────────────────────────────────────────────

  tar_target(
    name    = alpha_div,
    command = alpha_diversity_table(comm_matrix)
  ),

  # ── 4. Rarefaction ────────────────────────────────────────────────────────

  tar_target(
    name    = inext_results,
    command = run_inext(comm_matrix, q = 0, nboot = 200)
  ),

  # ── 5. Save processed outputs ──────────────────────────────────────────────

  tar_target(
    name    = save_outputs,
    command = {
      save_table(alpha_div,    "alpha_diversity")
      save_table(site_summary, "site_summary")
      saveRDS(inext_results, here::here("data/processed/inext_results.rds"))
      "done"
    }
  )

)
