# Ethogram — Zonosaurus karsteni
## Standard Behavioural Catalogue for Focal Follow Studies
## EcoR Toolkit · Module 2 · Kirindy CNFEREF, Madagascar

---

## How to use this ethogram

Before starting focal follows, both observers must:
1. Read all definitions carefully
2. Complete 2 hours of calibration together on the same individual
3. Achieve Cohen's Kappa ≥ 0.80 before independent data collection
4. Resolve ambiguous cases by discussion and update this document

**Recording unit:** instantaneous scan + continuous focal  
**Minimum duration recorded:** 0.5 seconds  
**Recording software:** BORIS (free, recommended) or paper datasheet

---

## Behaviour Codes

### ACTIVE BEHAVIOURS

| Code | Behaviour | Definition | Key diagnostic |
|------|-----------|------------|----------------|
| `FL` | Fourragement (foraging) | Animal moves tongue or investigates substrate for prey | Tongue visible or head lowered to ground/vegetation |
| `CP` | Capture_proie | Active attack and ingestion of prey item | Rapid head lunge + jaw closing on prey |
| `DL` | Deplacement_lent | Slow locomotion ≤ 1 body length/second | All four legs engaged, no sprint |
| `DR` | Deplacement_rapide | Fast locomotion > 1 body length/second | Sprint, usually escape or pursuit |
| `EX` | Exploration | Active investigation of novel object or area without tongue flick | Head raised, directed gaze, slow approach |

### STATIONARY BEHAVIOURS

| Code | Behaviour | Definition | Key diagnostic |
|------|-----------|------------|----------------|
| `IM` | Immobile | Animal stationary, no movement of limbs or head | Duration > 5 sec |
| `VG` | Vigilance | Head raised, eyes open, scanning environment | Distinguished from IM by active head rotation |
| `TR` | Thermorégulation | Postural or positional adjustment toward/away from sun | Body orientation change relative to sun angle |
| `BS` | Basking | Stationary exposure to direct sunlight, dorsum flattened | Flanks often expanded |

### SOCIAL BEHAVIOURS

| Code | Behaviour | Definition | Key diagnostic |
|------|-----------|------------|----------------|
| `IS` | Interaction_sociale | Physical or close-range contact with conspecific | Within 1 body length |
| `AG` | Agression | Threat display, chase, or bite toward conspecific | Lateral compression, throat display, pursuit |
| `CO` | Copulation | Mounting and cloacal contact | Males bite female neck |

### OTHER

| Code | Behaviour | Definition |
|------|-----------|------------|
| `AU` | Auto-soin | Scratching, licking own body |
| `HO` | Hors_vue | Individual out of sight > 30 sec — record duration |
| `NO` | Non_observable | Individual present but behaviour cannot be determined |

---

## Decision Rules for Ambiguous Cases

**Foraging vs. Exploration:**
- Tongue flick present → Fourragement (FL)
- No tongue flick, head investigation only → Exploration (EX)

**Immobile vs. Vigilance:**
- Eyes scanning, head rotates > 30° → Vigilance (VG)
- Eyes open but no head movement > 30° over 5 sec → Immobile (IM)

**Basking vs. Thermorégulation:**
- Animal stationary in sun > 10 sec → Basking (BS)
- Animal adjusting position (moving toward/away sun) → Thermorégulation (TR)

**Deplacement_lent vs. Fourragement:**
- Primary intent: locomotion between points → Deplacement_lent (DL)
- Primary intent: prey search with tongue → Fourragement (FL)
- If both simultaneously → record dominant behaviour

---

## Environmental Variables (record per session)

| Variable | Unit | Method | Notes |
|----------|------|--------|-------|
| `temp_air_c` | °C | Digital thermometer 1.5m above ground | Record at start + end of session |
| `temp_substrate_c` | °C | IR thermometer on ground surface | At capture point |
| `densite_arbustes_m2` | count/m² | Count all stems < 2cm DBH in 2×2m plot centred on animal | Repeat at 3 random points along transect |
| `couverture_sol_pct` | % | Visual estimate of litter cover | 0=bare soil, 100=full litter |
| `heure_debut` | h (decimal) | Digital watch | 08:30 = 8.5 |
| `couverture_nuageuse` | % | Visual estimate | 0=clear, 100=overcast |

---

## Data Quality Standards

- **Minimum session duration:** 20 minutes (discard shorter sessions)
- **Maximum gap (HO):** If > 5 minutes continuous out of sight, end session
- **Minimum sessions per individual:** 6 (for mixed model random effects)
- **Maximum consecutive days per individual:** 3 (to avoid pseudoreplication)
- **File naming:** `[site]_[ind_id]_[YYYYMMDD]_session[N].boris`

---

## Inter-Observer Reliability Protocol

Before field work:
```r
# Test Cohen's Kappa (run in R after calibration session)
library(irr)

# Load both observers' codes for the same 2-hour session
obs1 <- read.csv("calibration_observer1.csv")$behaviour_code
obs2 <- read.csv("calibration_observer2.csv")$behaviour_code

result <- kappa2(data.frame(obs1, obs2), weight = "unweighted")
print(result)
# Target: Kappa >= 0.80
# If Kappa < 0.80: review the behaviours with most disagreements
# and update definitions before proceeding
```

---

## Citation

Razafindrabe Maminiaina, H.F. (2017–2018). Ethogram for *Zonosaurus karsteni*  
focal follow studies at Kirindy CNFEREF, Madagascar. MSc thesis,  
Université d'Antananarivo.

*Adapted for EcoR Toolkit v2.0, 2026.*

