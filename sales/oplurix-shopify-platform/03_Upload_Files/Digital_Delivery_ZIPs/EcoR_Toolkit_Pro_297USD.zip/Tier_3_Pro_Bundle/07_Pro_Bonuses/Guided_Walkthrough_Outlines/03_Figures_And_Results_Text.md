# Guided Walkthrough Outline 3 Script

## Topic

Create figures and draft a Results section.

## Suggested Session Length

15 minutes.

## Lesson Outline

1. Run `07_richness_barplot.R`.
2. Run `08_abundance_heatmap.R`.
3. Run `06_nmds_permanova.R`.
4. Open exported figures.
5. Use prompt P42 to draft a Results section.
6. Show how to check AI-generated text against the actual R output.


