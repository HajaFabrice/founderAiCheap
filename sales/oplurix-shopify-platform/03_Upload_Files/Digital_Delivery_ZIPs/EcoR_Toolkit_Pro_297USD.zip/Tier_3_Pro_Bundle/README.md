# EcoR Toolkit - Pro

Price: USD $297

## What You Get

- Everything in Complete
- 5 annotated R Markdown notebooks based on real biodiversity research contexts
- Interactive statistical test decision tree for ecology workflows
- Full v3 conservation project template with stronger scripts from v2: spatial analysis, SDM starter, population/occupancy summaries, publication visualization, `run_pipeline.R`, `_targets.R`, prompts, data templates, and optional renv guidance
- 1 month of limited email Q&A support
- Private WhatsApp/community access file
- Guided walkthrough scripts and lesson outlines

## Important Seller Note

This Pro tier is designed to go live with manual support operations.

Use the included support terms and community-access file as part of fulfillment. The markdown files in `07_Pro_Bonuses/Guided_Walkthrough_Outlines/` are guided lesson outlines, not promised media files.

## Best For

Buyers who want the toolkit plus advanced notebooks, a statistical decision aid, a reproducible analysis workspace, and a closer support experience.

## Start Here

1. Begin with `README.md` and the quick-start guide
2. Review the Pro support terms in `07_Pro_Bonuses/`
3. Use `08_Reproducible_Project_Template/EcoR_Conservation_Project_Template/` when you want the full v3 technical project
4. Start inside that project with `source("0_setup.R")` then `source("1_data_import_clean.R")`, which uses the included transect template by default
5. Source `run_pipeline.R` and call `run_core()` for the safe community-ecology workflow, `run_advanced()` for the full sequence, or `run(c(0, 1, 4))` for a custom subset. The advanced spatial / SDM / occupancy scripts require `ECOR_INSTALL_ADVANCED <- TRUE` before re-running `0_setup.R`.
6. Review `_targets.R` if you want a reproducible `targets::tar_make()` run (core workflow only).
